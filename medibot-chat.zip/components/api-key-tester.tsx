"use client"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import ApiKeyUpdater from "@/components/api-key-updater"

export function ApiKeyTester() {
  return (
    <Tabs defaultValue="gemini" className="w-full">
      <TabsList className="grid w-full grid-cols-1">
        <TabsTrigger value="gemini">Gemini AI Integration</TabsTrigger>
      </TabsList>
      <TabsContent value="gemini">
        <ApiKeyUpdater />
      </TabsContent>
    </Tabs>
  )
}

export default ApiKeyTester
