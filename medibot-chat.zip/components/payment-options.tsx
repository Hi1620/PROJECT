"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { CreditCard, IndianRupee, QrCode } from "lucide-react"

export function PaymentOptions() {
  const [upiId, setUpiId] = useState("")
  const [paymentType, setPaymentType] = useState("regular")
  const [amount, setAmount] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)
  const [paymentStatus, setPaymentStatus] = useState<{ success: boolean; message: string } | null>(null)

  const handlePayment = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!upiId.trim() || !amount.trim()) {
      setPaymentStatus({
        success: false,
        message: "Please fill in all required fields",
      })
      return
    }

    setIsProcessing(true)
    setPaymentStatus(null)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // Validate UPI ID format (basic validation)
      const upiRegex = /^[\w.-]+@[\w.-]+$/
      if (!upiRegex.test(upiId)) {
        throw new Error("Invalid UPI ID format. Please use format: username@bankname")
      }

      setPaymentStatus({
        success: true,
        message: `Payment of ₹${amount} initiated successfully via ${paymentType} UPI`,
      })
    } catch (error) {
      setPaymentStatus({
        success: false,
        message: error instanceof Error ? error.message : "Payment processing failed",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle>Payment Options</CardTitle>
        <CardDescription>Make a secure payment for medical services</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="upi" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="upi" className="flex items-center gap-2">
              <IndianRupee className="h-4 w-4" />
              UPI
            </TabsTrigger>
            <TabsTrigger value="card" className="flex items-center gap-2">
              <CreditCard className="h-4 w-4" />
              Card
            </TabsTrigger>
            <TabsTrigger value="qr" className="flex items-center gap-2">
              <QrCode className="h-4 w-4" />
              QR Code
            </TabsTrigger>
          </TabsList>

          <TabsContent value="upi">
            <form onSubmit={handlePayment} className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label htmlFor="upiId">UPI ID</Label>
                <Input
                  id="upiId"
                  placeholder="username@bankname"
                  value={upiId}
                  onChange={(e) => setUpiId(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label>UPI Type</Label>
                <RadioGroup
                  defaultValue="regular"
                  value={paymentType}
                  onValueChange={setPaymentType}
                  className="flex flex-col space-y-1"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="regular" id="regular" />
                    <Label htmlFor="regular">Regular UPI</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="collect" id="collect" />
                    <Label htmlFor="collect">UPI Collect</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="intent" id="intent" />
                    <Label htmlFor="intent">UPI Intent</Label>
                  </div>
                </RadioGroup>
              </div>

              <div className="space-y-2">
                <Label htmlFor="amount">Amount (₹)</Label>
                <Input
                  id="amount"
                  type="number"
                  placeholder="Enter amount"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                />
              </div>

              {paymentStatus && (
                <div
                  className={`p-3 rounded-md ${
                    paymentStatus.success ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"
                  }`}
                >
                  {paymentStatus.message}
                </div>
              )}

              <Button type="submit" className="w-full" disabled={isProcessing}>
                {isProcessing ? "Processing..." : "Pay Now"}
              </Button>
            </form>
          </TabsContent>

          <TabsContent value="card">
            <div className="p-4 text-center text-muted-foreground">Card payment option will be available soon.</div>
          </TabsContent>

          <TabsContent value="qr">
            <div className="p-4 text-center">
              <div className="border border-dashed border-gray-300 rounded-md p-8 mb-4 mx-auto w-48 h-48 flex items-center justify-center">
                <QrCode className="w-24 h-24 text-gray-400" />
              </div>
              <p className="text-sm text-muted-foreground">Scan this QR code with your UPI app to make a payment</p>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter className="flex justify-between">
        <p className="text-xs text-muted-foreground">Secured by MediBot Payment Gateway</p>
      </CardFooter>
    </Card>
  )
}

export default PaymentOptions
