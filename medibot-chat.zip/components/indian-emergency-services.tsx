"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Phone,
  MapPin,
  Ambulance,
  Hospital,
  AlertCircle,
  Star,
  Clock,
  Navigation,
  ExternalLink,
  Calendar,
  Search,
} from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import {
  getHospitalsByPincode,
  getNearbyHospitals,
  searchHospitals,
  getEmergencyNumbers,
  type IndianHospital,
} from "@/lib/indian-hospitals-database"

export function IndianEmergencyServices() {
  const [pincode, setPincode] = useState("")
  const [searchQuery, setSearchQuery] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [hospitals, setHospitals] = useState<IndianHospital[]>([])
  const [error, setError] = useState<string | null>(null)

  const emergencyNumbers = getEmergencyNumbers()

  const findHospitalsByPincode = async () => {
    if (!pincode.trim() || pincode.length !== 6) {
      setError("Please enter a valid 6-digit pincode")
      return
    }

    setIsLoading(true)
    setError(null)
    setHospitals([])

    try {
      // Simulate API delay
      await new Promise((resolve) => setTimeout(resolve, 1000))

      const exactHospitals = getHospitalsByPincode(pincode)
      const nearbyHospitals = exactHospitals.length > 0 ? exactHospitals : getNearbyHospitals(pincode)

      if (nearbyHospitals.length === 0) {
        setError(`No hospitals found for pincode ${pincode}. Try searching by city name.`)
      } else {
        setHospitals(nearbyHospitals)
      }
    } catch (error) {
      setError("Error finding hospitals. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  const searchHospitalsByName = async () => {
    if (!searchQuery.trim()) {
      setError("Please enter a search term")
      return
    }

    setIsLoading(true)
    setError(null)
    setHospitals([])

    try {
      await new Promise((resolve) => setTimeout(resolve, 800))
      const results = searchHospitals(searchQuery)

      if (results.length === 0) {
        setError(`No hospitals found for "${searchQuery}". Try different keywords.`)
      } else {
        setHospitals(results)
      }
    } catch (error) {
      setError("Error searching hospitals. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  const makeCall = (phoneNumber: string) => {
    window.open(`tel:${phoneNumber}`, "_self")
  }

  const openWebsite = (website: string) => {
    window.open(website, "_blank", "noopener,noreferrer")
  }

  const bookAppointment = (hospital: IndianHospital) => {
    if (hospital.website) {
      // Try to open appointment booking page
      const appointmentUrl = `${hospital.website}/appointment`
      window.open(appointmentUrl, "_blank", "noopener,noreferrer")
    } else {
      // Fallback to calling the hospital
      makeCall(hospital.phone)
    }
  }

  const getDirections = (hospital: IndianHospital) => {
    const query = encodeURIComponent(`${hospital.name}, ${hospital.address}`)
    const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${query}`
    window.open(mapsUrl, "_blank", "noopener,noreferrer")
  }

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`h-4 w-4 ${i < Math.floor(rating) ? "text-yellow-400 fill-current" : "text-gray-300"}`}
      />
    ))
  }

  return (
    <div className="space-y-6">
      {/* Emergency Numbers */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center text-red-600">
            <Phone className="mr-2 h-5 w-5" />
            Emergency Numbers (India)
          </CardTitle>
          <CardDescription>Immediate emergency contact numbers</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-3 border rounded-lg bg-red-50 dark:bg-red-900/20">
              <div className="font-bold text-red-600 text-xl">{emergencyNumbers.national}</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">National Emergency</div>
              <Button
                size="sm"
                variant="outline"
                className="mt-2 w-full"
                onClick={() => makeCall(emergencyNumbers.national)}
              >
                Call Now
              </Button>
            </div>
            <div className="text-center p-3 border rounded-lg">
              <div className="font-bold text-blue-600 text-xl">{emergencyNumbers.ambulance}</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Ambulance</div>
              <Button
                size="sm"
                variant="outline"
                className="mt-2 w-full"
                onClick={() => makeCall(emergencyNumbers.ambulance)}
              >
                Call Now
              </Button>
            </div>
            <div className="text-center p-3 border rounded-lg">
              <div className="font-bold text-green-600 text-xl">{emergencyNumbers.police}</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Police</div>
              <Button
                size="sm"
                variant="outline"
                className="mt-2 w-full"
                onClick={() => makeCall(emergencyNumbers.police)}
              >
                Call Now
              </Button>
            </div>
            <div className="text-center p-3 border rounded-lg">
              <div className="font-bold text-orange-600 text-xl">{emergencyNumbers.fire}</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Fire Brigade</div>
              <Button
                size="sm"
                variant="outline"
                className="mt-2 w-full"
                onClick={() => makeCall(emergencyNumbers.fire)}
              >
                Call Now
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Hospital Search */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Hospital className="mr-2 h-5 w-5 text-blue-500" />
            Find Hospitals Near You
          </CardTitle>
          <CardDescription>Search hospitals by pincode or name</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="pincode" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="pincode">Search by Pincode</TabsTrigger>
              <TabsTrigger value="name">Search by Name/City</TabsTrigger>
            </TabsList>

            <TabsContent value="pincode" className="space-y-4">
              <div className="flex gap-2">
                <Input
                  placeholder="Enter 6-digit pincode (e.g., 110029)"
                  value={pincode}
                  onChange={(e) => setPincode(e.target.value)}
                  maxLength={6}
                  pattern="[0-9]{6}"
                />
                <Button onClick={findHospitalsByPincode} disabled={isLoading || pincode.length !== 6} className="gap-2">
                  <MapPin className="h-4 w-4" />
                  {isLoading ? "Searching..." : "Find Hospitals"}
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="name" className="space-y-4">
              <div className="flex gap-2">
                <Input
                  placeholder="Search by hospital name or city"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <Button onClick={searchHospitalsByName} disabled={isLoading || !searchQuery.trim()} className="gap-2">
                  <Search className="h-4 w-4" />
                  {isLoading ? "Searching..." : "Search"}
                </Button>
              </div>
            </TabsContent>
          </Tabs>

          {error && (
            <Alert variant="destructive" className="mt-4">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {hospitals.length > 0 && (
            <div className="mt-6 space-y-4">
              <h3 className="font-medium text-lg">
                Found {hospitals.length} hospital{hospitals.length > 1 ? "s" : ""}
              </h3>
              <div className="space-y-4 max-h-96 overflow-y-auto">
                {hospitals.map((hospital) => (
                  <Card key={hospital.id} className="border-l-4 border-l-blue-500">
                    <CardContent className="pt-4">
                      <div className="flex justify-between items-start mb-3">
                        <div className="flex-1">
                          <h4 className="font-semibold text-lg">{hospital.name}</h4>
                          <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">{hospital.address}</p>
                          <p className="text-sm text-gray-500 dark:text-gray-500">
                            {hospital.city}, {hospital.state} - {hospital.pincode}
                          </p>
                        </div>
                        <div className="flex flex-col items-end gap-2">
                          <Badge variant={hospital.type === "Government" ? "secondary" : "default"}>
                            {hospital.type}
                          </Badge>
                          <div className="flex items-center gap-1">
                            {renderStars(hospital.rating)}
                            <span className="text-sm text-gray-600 dark:text-gray-400 ml-1">{hospital.rating}</span>
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div>
                          <h5 className="font-medium text-sm mb-2">Specialties:</h5>
                          <div className="flex flex-wrap gap-1">
                            {hospital.specialties.slice(0, 3).map((specialty) => (
                              <Badge key={specialty} variant="outline" className="text-xs">
                                {specialty}
                              </Badge>
                            ))}
                            {hospital.specialties.length > 3 && (
                              <Badge variant="outline" className="text-xs">
                                +{hospital.specialties.length - 3} more
                              </Badge>
                            )}
                          </div>
                        </div>
                        <div>
                          <h5 className="font-medium text-sm mb-2">Services:</h5>
                          <div className="flex flex-wrap gap-1">
                            {hospital.services.slice(0, 3).map((service) => (
                              <Badge key={service} variant="outline" className="text-xs">
                                {service}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 mb-4 text-sm">
                        <Clock className="h-4 w-4 text-gray-500" />
                        <span>{hospital.timings}</span>
                        {hospital.emergencyServices && (
                          <Badge variant="destructive" className="ml-2">
                            24x7 Emergency
                          </Badge>
                        )}
                      </div>

                      <div className="flex flex-wrap gap-2">
                        <Button size="sm" onClick={() => makeCall(hospital.phone)} className="gap-1">
                          <Phone className="h-3 w-3" />
                          Call Hospital
                        </Button>

                        {hospital.emergencyPhone && (
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => makeCall(hospital.emergencyPhone)}
                            className="gap-1"
                          >
                            <Ambulance className="h-3 w-3" />
                            Emergency
                          </Button>
                        )}

                        <Button size="sm" variant="outline" onClick={() => bookAppointment(hospital)} className="gap-1">
                          <Calendar className="h-3 w-3" />
                          Book Appointment
                        </Button>

                        <Button size="sm" variant="outline" onClick={() => getDirections(hospital)} className="gap-1">
                          <Navigation className="h-3 w-3" />
                          Directions
                        </Button>

                        {hospital.website && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => openWebsite(hospital.website!)}
                            className="gap-1"
                          >
                            <ExternalLink className="h-3 w-3" />
                            Website
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </CardContent>
        <CardFooter>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            In case of a medical emergency, call 112 (National Emergency) or 108 (Ambulance) immediately.
          </p>
        </CardFooter>
      </Card>
    </div>
  )
}

export default IndianEmergencyServices
