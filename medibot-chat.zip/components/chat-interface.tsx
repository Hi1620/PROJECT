"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Send, User, Bot, Mic, Sparkles, Database } from "lucide-react"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import ReactMarkdown from "react-markdown"
import { Badge } from "@/components/ui/badge"
import InChatApiKeyManager from "@/components/in-chat-api-key-manager"

type Message = {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: Date
  source?: string
}

export function ChatInterface() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      role: "assistant",
      content:
        'Hello! I\'m MediBot, your AI-powered medical assistant. How can I help you today?\n\n**Quick tips:**\n- Ask about diseases, symptoms, or medications\n- Type **/setup-gemini** to enable advanced AI responses\n- Try asking: "What are the symptoms of diabetes?"',
      timestamp: new Date(),
    },
  ])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [showApiKeyManager, setShowApiKeyManager] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    scrollToBottom()
  }, [messages, showApiKeyManager])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  const handleApiKeyManagerComplete = () => {
    setShowApiKeyManager(false)
    // Add a confirmation message
    setMessages((prev) => [
      ...prev,
      {
        id: `assistant-${Date.now()}`,
        role: "assistant",
        content:
          '🎉 **Gemini AI Successfully Integrated!**\n\nYour chatbot is now powered by Google\'s advanced AI. You can now ask complex medical questions and get detailed, accurate responses.\n\n**Try asking:**\n- "Explain the difference between Type 1 and Type 2 diabetes"\n- "What lifestyle changes can help with hypertension?"\n- "How does the immune system work?"',
        timestamp: new Date(),
        source: "system",
      },
    ])
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim()) return

    // Check for special commands
    if (
      input.toLowerCase() === "/setup-gemini" ||
      input.toLowerCase() === "/setup" ||
      input.toLowerCase() === "/api-key"
    ) {
      // Add user message
      const userMessage: Message = {
        id: `user-${Date.now()}`,
        role: "user",
        content: input,
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, userMessage])
      setInput("")
      setShowApiKeyManager(true)
      return
    }

    // Regular message handling
    const userMessage: Message = {
      id: `user-${Date.now()}`,
      role: "user",
      content: input,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsLoading(true)

    try {
      // Call the API
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          messages: [...messages, userMessage].map((m) => ({
            role: m.role,
            content: m.content,
          })),
        }),
      })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      const data = await response.json()

      // Add assistant message
      setMessages((prev) => [
        ...prev,
        {
          id: `assistant-${Date.now()}`,
          role: "assistant",
          content: data.content || "I'm sorry, I couldn't process your request.",
          timestamp: new Date(),
          source: data.source || "database",
        },
      ])
    } catch (error) {
      console.error("Error in chat:", error)

      // Add error message
      setMessages((prev) => [
        ...prev,
        {
          id: `error-${Date.now()}`,
          role: "assistant",
          content: "I'm sorry, I encountered an error processing your request. Please try again.",
          timestamp: new Date(),
        },
      ])
    } finally {
      setIsLoading(false)
    }
  }

  const getSourceBadge = (source?: string) => {
    if (source === "gemini-1.5-flash") {
      return (
        <Badge
          variant="outline"
          className="flex items-center gap-1 text-xs bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-900/20 dark:text-blue-300 dark:border-blue-800"
        >
          <Sparkles className="h-3 w-3" />
          Gemini AI
        </Badge>
      )
    } else if (source === "database") {
      return (
        <Badge
          variant="outline"
          className="flex items-center gap-1 text-xs bg-gray-50 text-gray-700 border-gray-200 dark:bg-gray-900/20 dark:text-gray-300 dark:border-gray-800"
        >
          <Database className="h-3 w-3" />
          Database
        </Badge>
      )
    }
    return null
  }

  return (
    <Card className="w-full h-[70vh] flex flex-col">
      <CardContent className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <div key={message.id} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}>
            <div className={`flex items-start gap-2 max-w-[80%] ${message.role === "user" ? "flex-row-reverse" : ""}`}>
              <Avatar className={message.role === "user" ? "bg-primary" : "bg-secondary"}>
                <AvatarFallback>{message.role === "user" ? <User size={16} /> : <Bot size={16} />}</AvatarFallback>
              </Avatar>
              <div
                className={`rounded-lg p-3 ${
                  message.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted"
                }`}
              >
                {message.role === "user" ? (
                  <div className="whitespace-pre-line">{message.content}</div>
                ) : (
                  <div className="prose prose-sm dark:prose-invert max-w-none">
                    <ReactMarkdown>{message.content}</ReactMarkdown>
                  </div>
                )}
                <div className="flex items-center justify-between mt-2">
                  <div
                    className={`text-xs ${
                      message.role === "user" ? "text-primary-foreground/70" : "text-muted-foreground"
                    }`}
                  >
                    {message.timestamp.toLocaleTimeString([], {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </div>

                  {message.role === "assistant" && getSourceBadge(message.source)}
                </div>
              </div>
            </div>
          </div>
        ))}

        {showApiKeyManager && <InChatApiKeyManager onComplete={handleApiKeyManagerComplete} />}

        {isLoading && (
          <div className="flex justify-start">
            <div className="flex items-start gap-2">
              <Avatar className="bg-secondary">
                <AvatarFallback>
                  <Bot size={16} />
                </AvatarFallback>
              </Avatar>
              <div className="bg-muted rounded-lg p-3">
                <div className="flex space-x-2">
                  <div
                    className="w-2 h-2 rounded-full bg-primary animate-bounce"
                    style={{ animationDelay: "0ms" }}
                  ></div>
                  <div
                    className="w-2 h-2 rounded-full bg-primary animate-bounce"
                    style={{ animationDelay: "150ms" }}
                  ></div>
                  <div
                    className="w-2 h-2 rounded-full bg-primary animate-bounce"
                    style={{ animationDelay: "300ms" }}
                  ></div>
                </div>
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </CardContent>

      <div className="p-4 border-t">
        <form onSubmit={handleSubmit} className="flex items-center space-x-2">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask about symptoms, diseases, or type /setup-gemini..."
            className="flex-1"
            disabled={isLoading}
          />
          <Button type="button" variant="outline" size="icon" disabled={isLoading}>
            <Mic className="h-4 w-4" />
          </Button>
          <Button type="submit" size="icon" disabled={isLoading || !input.trim()}>
            <Send className="h-4 w-4" />
          </Button>
        </form>
      </div>
    </Card>
  )
}

export default ChatInterface
