"use client"

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Globe, MapPin } from "lucide-react"
import IndianEmergencyServices from "@/components/indian-emergency-services"

// Keep the original emergency services for international users
function InternationalEmergencyServices() {
  const emergencyNumbers = [
    { country: "United States", number: "911" },
    { country: "United Kingdom", number: "999" },
    { country: "European Union", number: "112" },
    { country: "Australia", number: "000" },
    { country: "Canada", number: "911" },
  ]

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Globe className="mr-2 h-5 w-5 text-blue-500" />
          International Emergency Numbers
        </CardTitle>
        <CardDescription>Emergency contact numbers for different countries</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {emergencyNumbers.map((item, index) => (
            <div key={index} className="flex justify-between items-center p-3 border rounded-md">
              <span>{item.country}</span>
              <span className="font-bold text-red-500">{item.number}</span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

export function EmergencyServices() {
  return (
    <div className="space-y-6">
      <Tabs defaultValue="india" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="india" className="flex items-center gap-2">
            <MapPin className="h-4 w-4" />
            India
          </TabsTrigger>
          <TabsTrigger value="international" className="flex items-center gap-2">
            <Globe className="h-4 w-4" />
            International
          </TabsTrigger>
        </TabsList>

        <TabsContent value="india">
          <IndianEmergencyServices />
        </TabsContent>

        <TabsContent value="international">
          <InternationalEmergencyServices />
        </TabsContent>
      </Tabs>
    </div>
  )
}

export default EmergencyServices
