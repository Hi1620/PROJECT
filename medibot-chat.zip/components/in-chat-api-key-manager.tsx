"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertCircle, CheckCircle, Key } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface InChatApiKeyManagerProps {
  onComplete: () => void
}

export function InChatApiKeyManager({ onComplete }: InChatApiKeyManagerProps) {
  const [apiKey, setApiKey] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null)

  const testApiKey = async () => {
    if (!apiKey.trim()) {
      setTestResult({ success: false, message: "Please enter an API key" })
      return
    }

    setIsLoading(true)
    setTestResult(null)

    try {
      const response = await fetch("/api/diagnose-api", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ apiKey }),
      })

      const data = await response.json()

      if (response.ok) {
        setTestResult({
          success: true,
          message: data.message || "API key is valid! Gemini AI is available.",
        })
      } else {
        setTestResult({
          success: false,
          message: data.error || "Failed to validate API key",
        })
      }
    } catch (error) {
      setTestResult({
        success: false,
        message: "Error testing API key. Please try again.",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const updateApiKey = async () => {
    if (!apiKey.trim()) {
      setTestResult({ success: false, message: "Please enter an API key" })
      return
    }

    setIsLoading(true)
    setTestResult(null)

    try {
      const response = await fetch("/api/update-key", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ apiKey }),
      })

      const data = await response.json()

      if (response.ok) {
        setTestResult({
          success: true,
          message: "API key updated successfully! Gemini AI is now powering MediBot.",
        })
        // Wait a moment before completing to let the user see the success message
        setTimeout(() => {
          onComplete()
        }, 2000)
      } else {
        setTestResult({
          success: false,
          message: data.error || "Failed to update API key",
        })
      }
    } catch (error) {
      setTestResult({
        success: false,
        message: "Error updating API key. Please try again.",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card className="w-full mb-4">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Key className="h-5 w-5" />
          Set Up Gemini AI
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="space-y-2">
            <label htmlFor="inChatApiKey" className="text-sm font-medium">
              Google API Key
            </label>
            <Input
              id="inChatApiKey"
              type="password"
              placeholder="Enter your Google API key"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
            />
            <p className="text-xs text-muted-foreground">
              Get your API key from the{" "}
              <a
                href="https://makersuite.google.com/app/apikey"
                target="_blank"
                rel="noopener noreferrer"
                className="text-primary underline"
              >
                Google AI Studio
              </a>
            </p>
          </div>

          {testResult && (
            <Alert
              variant={testResult.success ? "default" : "destructive"}
              className={testResult.success ? "bg-green-50 text-green-700 border-green-200" : undefined}
            >
              {testResult.success ? <CheckCircle className="h-4 w-4" /> : <AlertCircle className="h-4 w-4" />}
              <AlertDescription>{testResult.message}</AlertDescription>
            </Alert>
          )}
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button variant="outline" onClick={testApiKey} disabled={isLoading}>
          {isLoading ? "Testing..." : "Test Key"}
        </Button>
        <Button onClick={updateApiKey} disabled={isLoading}>
          {isLoading ? "Updating..." : "Save & Activate"}
        </Button>
      </CardFooter>
    </Card>
  )
}

export default InChatApiKeyManager
