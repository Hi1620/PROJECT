"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertCircle, CheckCircle, Key, ExternalLink } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

export function ApiKeyUpdater() {
  const [apiKey, setApiKey] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null)

  const testApiKey = async () => {
    if (!apiKey.trim()) {
      setTestResult({ success: false, message: "Please enter an API key" })
      return
    }

    setIsLoading(true)
    setTestResult(null)

    try {
      const response = await fetch("/api/diagnose-api", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ apiKey }),
      })

      const data = await response.json()

      if (response.ok) {
        setTestResult({
          success: true,
          message: data.message || "API key is valid! Gemini AI is available.",
        })
      } else {
        setTestResult({
          success: false,
          message: data.error || "Failed to validate API key",
        })
      }
    } catch (error) {
      setTestResult({
        success: false,
        message: "Error testing API key. Please check your internet connection and try again.",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const updateApiKey = async () => {
    if (!apiKey.trim()) {
      setTestResult({ success: false, message: "Please enter an API key" })
      return
    }

    setIsLoading(true)
    setTestResult(null)

    try {
      const response = await fetch("/api/update-key", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ apiKey }),
      })

      const data = await response.json()

      if (response.ok) {
        setTestResult({
          success: true,
          message:
            "✅ API key updated successfully! Gemini AI is now powering MediBot. You can start asking complex medical questions.",
        })
        // Clear the input for security
        setApiKey("")
      } else {
        setTestResult({
          success: false,
          message: data.error || "Failed to update API key",
        })
      }
    } catch (error) {
      setTestResult({
        success: false,
        message: "Error updating API key. Please check your internet connection and try again.",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Key className="h-5 w-5" />
          Gemini AI Integration
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
            <h4 className="font-medium text-blue-900 dark:text-blue-100 mb-2">How to get your API key:</h4>
            <ol className="text-sm text-blue-800 dark:text-blue-200 space-y-1">
              <li>1. Visit Google AI Studio</li>
              <li>2. Sign in with your Google account</li>
              <li>3. Click "Get API Key" or "Create API Key"</li>
              <li>4. Copy the generated key and paste it below</li>
            </ol>
            <a
              href="https://makersuite.google.com/app/apikey"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 text-blue-600 dark:text-blue-400 hover:underline mt-2"
            >
              Open Google AI Studio <ExternalLink className="h-3 w-3" />
            </a>
          </div>

          <div className="space-y-2">
            <label htmlFor="apiKey" className="text-sm font-medium">
              Google API Key
            </label>
            <Input
              id="apiKey"
              type="password"
              placeholder="AIzaSy..."
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              className="font-mono"
            />
            <p className="text-xs text-muted-foreground">
              Your API key is encrypted and stored securely. It will only be used to communicate with Google's Gemini
              AI.
            </p>
          </div>

          {testResult && (
            <Alert
              variant={testResult.success ? "default" : "destructive"}
              className={
                testResult.success
                  ? "bg-green-50 text-green-700 border-green-200 dark:bg-green-900/20 dark:text-green-300 dark:border-green-800"
                  : undefined
              }
            >
              {testResult.success ? <CheckCircle className="h-4 w-4" /> : <AlertCircle className="h-4 w-4" />}
              <AlertDescription className="whitespace-pre-line">{testResult.message}</AlertDescription>
            </Alert>
          )}
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button variant="outline" onClick={testApiKey} disabled={isLoading || !apiKey.trim()}>
          {isLoading ? "Testing..." : "Test Key"}
        </Button>
        <Button onClick={updateApiKey} disabled={isLoading || !apiKey.trim()}>
          {isLoading ? "Saving..." : "Save & Activate"}
        </Button>
      </CardFooter>
    </Card>
  )
}

export default ApiKeyUpdater
