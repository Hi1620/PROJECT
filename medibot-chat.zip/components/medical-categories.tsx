"use client"

import { useState } from "react"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Search } from "lucide-react"

export function MedicalCategories() {
  const [searchTerm, setSearchTerm] = useState("")

  const categories = [
    {
      name: "Cardiovascular",
      topics: [
        {
          title: "Heart Attack",
          content:
            "A heart attack occurs when blood flow to part of the heart is blocked, causing damage to the heart muscle.",
        },
        {
          title: "Hypertension",
          content:
            "High blood pressure is a common condition that can lead to serious health problems if left untreated.",
        },
        {
          title: "Stroke",
          content: "A stroke occurs when blood flow to part of the brain is interrupted, causing brain cells to die.",
        },
      ],
    },
    {
      name: "Respiratory",
      topics: [
        {
          title: "Asthma",
          content:
            "Asthma is a chronic condition that affects the airways, causing wheezing, shortness of breath, and coughing.",
        },
        {
          title: "COPD",
          content:
            "Chronic Obstructive Pulmonary Disease is a progressive lung disease that makes it difficult to breathe.",
        },
        { title: "Pneumonia", content: "Pneumonia is an infection that inflames the air sacs in one or both lungs." },
      ],
    },
    {
      name: "Digestive",
      topics: [
        {
          title: "GERD",
          content:
            "Gastroesophageal Reflux Disease is a chronic digestive disease that occurs when stomach acid flows back into the esophagus.",
        },
        {
          title: "IBS",
          content:
            "Irritable Bowel Syndrome is a common disorder that affects the large intestine, causing abdominal pain, bloating, and changes in bowel habits.",
        },
        {
          title: "Ulcerative Colitis",
          content:
            "Ulcerative Colitis is a chronic inflammatory bowel disease that causes inflammation and ulcers in the digestive tract.",
        },
      ],
    },
    {
      name: "Mental Health",
      topics: [
        {
          title: "Depression",
          content: "Depression is a mood disorder that causes a persistent feeling of sadness and loss of interest.",
        },
        {
          title: "Anxiety",
          content:
            "Anxiety disorders involve excessive worry, fear, or nervousness that can interfere with daily activities.",
        },
        {
          title: "PTSD",
          content:
            "Post-Traumatic Stress Disorder is a mental health condition triggered by experiencing or witnessing a terrifying event.",
        },
      ],
    },
  ]

  const filteredCategories = categories
    .map((category) => ({
      ...category,
      topics: category.topics.filter(
        (topic) =>
          topic.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          topic.content.toLowerCase().includes(searchTerm.toLowerCase()),
      ),
    }))
    .filter((category) => category.topics.length > 0)

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Medical Information</CardTitle>
          <CardDescription>Browse medical topics by category or search for specific information</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="relative mb-6">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search medical topics..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-8"
            />
          </div>

          {filteredCategories.length === 0 ? (
            <p className="text-center py-4 text-gray-500">No results found. Try a different search term.</p>
          ) : (
            <Accordion type="multiple" className="space-y-4">
              {filteredCategories.map((category, index) => (
                <Card key={index} className="overflow-hidden">
                  <AccordionItem value={category.name} className="border-none">
                    <AccordionTrigger className="px-4 py-2 hover:bg-gray-50 dark:hover:bg-gray-800">
                      <h3 className="text-lg font-medium">{category.name}</h3>
                    </AccordionTrigger>
                    <AccordionContent>
                      <div className="space-y-4 p-4 pt-0">
                        {category.topics.map((topic, topicIndex) => (
                          <div key={topicIndex} className="border-t pt-4 first:border-t-0 first:pt-0">
                            <h4 className="font-medium">{topic.title}</h4>
                            <p className="mt-1 text-sm text-gray-500">{topic.content}</p>
                          </div>
                        ))}
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                </Card>
              ))}
            </Accordion>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

export default MedicalCategories
