"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { MessageSquare, AlertCircle, BookOpen, Settings, CreditCard, Home } from "lucide-react"
import ChatInterface from "@/components/chat-interface"
import EmergencyServices from "@/components/emergency-services"
import MedicalCategories from "@/components/medical-categories"
import ApiKeyTester from "@/components/api-key-tester"
import PaymentOptions from "@/components/payment-options"
import Link from "next/link"

export default function AppPage() {
  const [activeTab, setActiveTab] = useState("chat")
  const [isSettingsOpen, setIsSettingsOpen] = useState(false)
  const [isPaymentOpen, setIsPaymentOpen] = useState(false)

  return (
    <main className="flex min-h-screen flex-col">
      <header className="border-b bg-white dark:bg-gray-950 sticky top-0 z-10">
        <div className="container flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-2">
            <MessageSquare className="h-6 w-6 text-blue-500" />
            <h1 className="text-xl font-bold">MediBot</h1>
          </div>
          <div className="flex items-center gap-2">
            <Link href="/">
              <Button variant="outline" size="sm" className="flex items-center gap-2">
                <Home className="h-4 w-4" />
                <span>Home</span>
              </Button>
            </Link>
            <Dialog open={isPaymentOpen} onOpenChange={setIsPaymentOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm" className="flex items-center gap-2">
                  <CreditCard className="h-4 w-4" />
                  <span>Payment</span>
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle>Payment Options</DialogTitle>
                </DialogHeader>
                <PaymentOptions />
              </DialogContent>
            </Dialog>

            <Dialog open={isSettingsOpen} onOpenChange={setIsSettingsOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" size="icon">
                  <Settings className="h-5 w-5" />
                  <span className="sr-only">Settings</span>
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>API Settings</DialogTitle>
                </DialogHeader>
                <ApiKeyTester />
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </header>

      <div className="container flex-1 p-4">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full flex flex-col">
          <TabsList className="grid w-full grid-cols-3 mb-4">
            <TabsTrigger value="chat" className="flex items-center gap-2">
              <MessageSquare className="h-4 w-4" />
              Chat
            </TabsTrigger>
            <TabsTrigger value="medical" className="flex items-center gap-2">
              <BookOpen className="h-4 w-4" />
              Medical Info
            </TabsTrigger>
            <TabsTrigger value="emergency" className="flex items-center gap-2">
              <AlertCircle className="h-4 w-4" />
              Emergency
            </TabsTrigger>
          </TabsList>

          <div className="flex-1">
            <TabsContent value="chat" className="h-full">
              <ChatInterface />
            </TabsContent>

            <TabsContent value="medical">
              <MedicalCategories />
            </TabsContent>

            <TabsContent value="emergency">
              <EmergencyServices />
            </TabsContent>
          </div>
        </Tabs>
      </div>
    </main>
  )
}
