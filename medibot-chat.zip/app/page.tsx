import LandingPage from "@/app/landing-page"

export default function Home() {
  return <LandingPage />
}
