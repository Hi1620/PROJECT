import { NextResponse } from "next/server"

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const location = searchParams.get("location")

  if (!location) {
    return NextResponse.json({ error: "Location parameter is required" }, { status: 400 })
  }

  // Mock data for demonstration
  const ambulanceServices = [
    {
      name: "City Emergency Services",
      address: `100 Emergency Lane, ${location}`,
      phone: "+1 (555) 911-0000",
    },
    {
      name: "Rapid Response Ambulance",
      address: `200 Rescue Blvd, ${location}`,
      phone: "+1 (555) 911-1111",
    },
  ]

  return NextResponse.json({ results: ambulanceServices })
}
