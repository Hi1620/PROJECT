import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const { apiKey } = await request.json()

    if (!apiKey) {
      return NextResponse.json({ error: "API key is required" }, { status: 400 })
    }

    if (apiKey.length < 20) {
      return NextResponse.json({ error: "API key appears to be too short. Please check your key." }, { status: 400 })
    }

    // Test the API key with a simple request to Gemini
    try {
      console.log("Testing API key with Gemini...")

      const testResponse = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            contents: [
              {
                parts: [
                  {
                    text: "Hello, can you respond with just the word 'working' to test the API?",
                  },
                ],
              },
            ],
            generationConfig: {
              temperature: 0.1,
              maxOutputTokens: 10,
            },
          }),
        },
      )

      if (!testResponse.ok) {
        const errorData = await testResponse.json().catch(() => ({}))
        console.error("Gemini API test failed:", testResponse.status, errorData)

        if (testResponse.status === 400) {
          return NextResponse.json(
            { error: "Invalid API key format. Please check your key and try again." },
            { status: 400 },
          )
        } else if (testResponse.status === 403) {
          return NextResponse.json(
            { error: "API key is not authorized. Please check your key permissions in Google AI Studio." },
            { status: 400 },
          )
        } else {
          return NextResponse.json(
            { error: `API validation failed: ${errorData.error?.message || "Unknown error"}` },
            { status: 400 },
          )
        }
      }

      const responseData = await testResponse.json()
      console.log("Gemini API test successful:", responseData)

      // Check if we got a valid response
      if (responseData.candidates && responseData.candidates[0]) {
        return NextResponse.json({
          success: true,
          message: "✅ API key is valid! Gemini AI is ready to power your medical assistant.",
        })
      } else {
        return NextResponse.json({ error: "API key works but received unexpected response format." }, { status: 400 })
      }
    } catch (error) {
      console.error("Error testing Gemini API key:", error)
      return NextResponse.json(
        { error: "Failed to connect to Gemini API. Please check your internet connection and try again." },
        { status: 500 },
      )
    }
  } catch (error) {
    console.error("Error in diagnose-api route:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
