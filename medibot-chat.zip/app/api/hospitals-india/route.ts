import { NextResponse } from "next/server"
import { getHospitalsByPincode, getNearbyHospitals, searchHospitals } from "@/lib/indian-hospitals-database"

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const pincode = searchParams.get("pincode")
  const query = searchParams.get("query")
  const type = searchParams.get("type") // "pincode" or "search"

  try {
    if (type === "pincode" && pincode) {
      if (pincode.length !== 6 || !/^\d{6}$/.test(pincode)) {
        return NextResponse.json({ error: "Invalid pincode format" }, { status: 400 })
      }

      const exactHospitals = getHospitalsByPincode(pincode)
      const hospitals = exactHospitals.length > 0 ? exactHospitals : getNearbyHospitals(pincode)

      return NextResponse.json({
        hospitals,
        message:
          exactHospitals.length > 0
            ? `Found ${hospitals.length} hospitals in pincode ${pincode}`
            : `Found ${hospitals.length} nearby hospitals for pincode ${pincode}`,
      })
    }

    if (type === "search" && query) {
      const hospitals = searchHospitals(query)
      return NextResponse.json({
        hospitals,
        message: `Found ${hospitals.length} hospitals matching "${query}"`,
      })
    }

    return NextResponse.json({ error: "Missing required parameters" }, { status: 400 })
  } catch (error) {
    console.error("Error in hospitals-india API:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
