import { NextResponse } from "next/server"
import fs from "fs"
import path from "path"

// In a real application, you would use a more secure storage method
// This is just for demonstration purposes
const ENV_FILE_PATH = path.join(process.cwd(), ".env.local")

export async function POST(request: Request) {
  try {
    const { apiKey } = await request.json()

    if (!apiKey) {
      return NextResponse.json({ error: "API key is required" }, { status: 400 })
    }

    // Test the API key before saving it
    try {
      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${apiKey}`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      })

      if (!response.ok) {
        const errorData = await response.json()
        return NextResponse.json(
          { error: `Invalid API key: ${errorData.error?.message || "Unknown error"}` },
          { status: 400 },
        )
      }

      // In a real production app, you would store this in a secure database
      // or environment variable management system
      // For this demo, we'll use environment variables

      // Set the environment variable for the current process
      process.env.GOOGLE_API_KEY = apiKey

      // Try to save to .env.local file if possible (this works in development)
      try {
        let envContent = ""

        // Read existing content if file exists
        if (fs.existsSync(ENV_FILE_PATH)) {
          envContent = fs.readFileSync(ENV_FILE_PATH, "utf8")

          // Replace existing GOOGLE_API_KEY line or add a new one
          if (envContent.includes("GOOGLE_API_KEY=")) {
            envContent = envContent.replace(/GOOGLE_API_KEY=.*/, `GOOGLE_API_KEY=${apiKey}`)
          } else {
            envContent += `\nGOOGLE_API_KEY=${apiKey}`
          }
        } else {
          envContent = `GOOGLE_API_KEY=${apiKey}`
        }

        // Write back to file
        fs.writeFileSync(ENV_FILE_PATH, envContent)
      } catch (fileError) {
        console.warn("Could not save API key to .env.local file:", fileError)
        // This is not a critical error, as we've already set the process env var
      }

      return NextResponse.json({
        success: true,
        message: "API key updated successfully",
      })
    } catch (error) {
      console.error("Error validating API key:", error)
      return NextResponse.json(
        { error: "Failed to validate API key. Please check your key and try again." },
        { status: 500 },
      )
    }
  } catch (error) {
    console.error("Error in update-key route:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
