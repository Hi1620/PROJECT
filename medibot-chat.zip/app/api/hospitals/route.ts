import { NextResponse } from "next/server"

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const location = searchParams.get("location")

  if (!location) {
    return NextResponse.json({ error: "Location parameter is required" }, { status: 400 })
  }

  // Mock data for demonstration
  const hospitals = [
    {
      name: "General Hospital",
      address: `123 Main St, ${location}`,
      phone: "+1 (555) 123-4567",
    },
    {
      name: "Community Medical Center",
      address: `456 Oak Ave, ${location}`,
      phone: "+1 (555) 987-6543",
    },
    {
      name: "Regional Health Center",
      address: `789 Pine Rd, ${location}`,
      phone: "+1 (555) 456-7890",
    },
  ]

  return NextResponse.json({ results: hospitals })
}
