import { NextResponse } from "next/server"
import {
  getDiseaseByName,
  searchDiseases,
  getDiseasesBySymptom,
  getDiseasesByMedicine,
} from "@/lib/disease-medicine-dataset"

// Set a longer timeout for responses
export const maxDuration = 30

// System prompt for the medical chatbot
const SYSTEM_PROMPT = `You are MediBot, a helpful and informative medical assistant chatbot.

Your primary goal is to provide accurate, helpful information about general health topics, medical conditions, treatments, and preventive care.

Guidelines:
- Provide clear, evidence-based medical information
- Use simple language that's easy to understand
- Format responses with markdown: use ## for main headings, ### for subheadings, and * for bullet points
- Be empathetic and supportive when discussing health concerns
- Always clarify that you're providing general information, not personalized medical advice
- Recommend consulting healthcare professionals for specific medical concerns
- For emergencies, advise seeking immediate medical attention
- Do not diagnose specific conditions or prescribe treatments
- Focus on educational content about health topics

Remember that you are not a replacement for professional medical care.`

// Disclaimer to add to all responses
const DISCLAIMER =
  "\n\n*Please note: This is general information and not personalized medical advice. For specific concerns, please consult a healthcare professional.*"

export async function POST(req: Request) {
  console.log("Chat API called:", new Date().toISOString())

  try {
    // Parse the request body
    const body = await req.json().catch((error) => {
      console.error("Error parsing request body:", error)
      return null
    })

    // Check if body parsing failed
    if (!body) {
      console.error("Failed to parse request body")
      return NextResponse.json(
        {
          id: "error-" + Date.now(),
          role: "assistant",
          content: "I encountered an error processing your request. Invalid request format.",
        },
        { status: 400 },
      )
    }

    const { messages } = body

    // Validate input
    if (!messages || !Array.isArray(messages)) {
      console.error("Invalid messages format:", messages)
      return NextResponse.json(
        {
          id: "error-" + Date.now(),
          role: "assistant",
          content: "I encountered an error processing your request. Invalid messages format.",
        },
        { status: 400 },
      )
    }

    // Get the last user message
    const lastUserMessage = messages.filter((msg: any) => msg.role === "user").pop()?.content || ""
    const userQuery = typeof lastUserMessage === "string" ? lastUserMessage.trim() : String(lastUserMessage).trim()

    // Check for API key setup commands
    if (
      userQuery.toLowerCase() === "/setup-gemini" ||
      userQuery.toLowerCase() === "/setup" ||
      userQuery.toLowerCase() === "/api-key"
    ) {
      return NextResponse.json({
        id: "response-" + Date.now(),
        role: "assistant",
        content: `## Set Up Gemini AI

Please enter your Google API key in the form below to integrate Gemini AI with MediBot.

You can get your API key from the [Google AI Studio](https://makersuite.google.com/app/apikey).`,
        source: "system",
      })
    }

    // Check for UPI-related queries
    if (userQuery.toLowerCase().includes("upi") || userQuery.toLowerCase().includes("payment")) {
      return NextResponse.json({
        id: "response-" + Date.now(),
        role: "assistant",
        content: `## Payment Options

I've added a payment button to the top of the screen where you can:

1. Set up your UPI ID
2. Choose between Regular UPI, UPI Collect, or UPI Intent
3. Enter the payment amount

You can click the **Payment** button in the top right corner to access these options.

${DISCLAIMER}`,
      })
    }

    // Try to use the Gemini API first if available
    const apiKey = process.env.GOOGLE_API_KEY

    if (apiKey) {
      try {
        console.log("Attempting to use Gemini API with conversation history")

        // Convert messages to Gemini format
        const geminiMessages = messages
          .filter((msg: any) => msg.role === "user" || msg.role === "assistant")
          .map((msg: any) => ({
            role: msg.role === "assistant" ? "model" : "user",
            parts: [{ text: msg.content }],
          }))

        // Add system prompt as the first message
        const contents = [
          {
            role: "user",
            parts: [{ text: SYSTEM_PROMPT }],
          },
          {
            role: "model",
            parts: [
              {
                text: "I understand. I'm MediBot, your medical assistant. I'll provide helpful, accurate medical information while always recommending professional medical consultation for specific concerns. How can I help you today?",
              },
            ],
          },
          ...geminiMessages,
        ]

        const response = await fetch(
          `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              contents: contents,
              generationConfig: {
                temperature: 0.7,
                maxOutputTokens: 1000,
                topP: 0.8,
                topK: 40,
              },
              safetySettings: [
                {
                  category: "HARM_CATEGORY_HARASSMENT",
                  threshold: "BLOCK_MEDIUM_AND_ABOVE",
                },
                {
                  category: "HARM_CATEGORY_HATE_SPEECH",
                  threshold: "BLOCK_MEDIUM_AND_ABOVE",
                },
                {
                  category: "HARM_CATEGORY_SEXUALLY_EXPLICIT",
                  threshold: "BLOCK_MEDIUM_AND_ABOVE",
                },
                {
                  category: "HARM_CATEGORY_DANGEROUS_CONTENT",
                  threshold: "BLOCK_MEDIUM_AND_ABOVE",
                },
              ],
            }),
          },
        )

        if (response.ok) {
          const data = await response.json()

          // Extract the response text
          let responseText = ""
          if (
            data.candidates &&
            data.candidates[0] &&
            data.candidates[0].content &&
            data.candidates[0].content.parts &&
            data.candidates[0].content.parts.length > 0
          ) {
            responseText = data.candidates[0].content.parts[0].text || ""

            // If we got a valid response, return it
            if (responseText && responseText.trim().length > 0) {
              console.log("Successfully used Gemini API")

              // Add disclaimer if it's not already there
              if (!responseText.includes("*Please note:") && !responseText.includes("consult")) {
                responseText += DISCLAIMER
              }

              return NextResponse.json({
                id: "response-" + Date.now(),
                role: "assistant",
                content: responseText,
                source: "gemini-1.5-flash",
              })
            }
          }

          // If we get here, the response was empty or malformed
          console.error("Empty or malformed Gemini response:", data)
        } else {
          const errorText = await response.text()
          console.error("Gemini API error:", response.status, errorText)

          // Try to parse error for better handling
          try {
            const errorData = JSON.parse(errorText)
            if (errorData.error?.message?.includes("API key")) {
              console.error("API key issue detected")
            }
          } catch (e) {
            // Ignore JSON parse errors
          }
        }
      } catch (error) {
        console.error("Error with Gemini API:", error)
      }
    } else {
      console.log("No Gemini API key available")
    }

    // Fallback to database search if Gemini fails or is unavailable
    console.log("Using fallback database search")

    // Check if the user is asking about Gemini integration
    if (
      userQuery.toLowerCase().includes("gemini") ||
      userQuery.toLowerCase().includes("api key") ||
      userQuery.toLowerCase().includes("integrate")
    ) {
      return NextResponse.json({
        id: "response-" + Date.now(),
        role: "assistant",
        content: `## Gemini AI Integration

To integrate Gemini AI with MediBot, you have two options:

### Option 1: In-Chat Setup (Recommended)
Simply type **/setup-gemini** in the chat to start the setup process directly in this conversation.

### Option 2: Settings Menu
1. Click the **Settings** icon in the top right corner
2. Enter your API key in the "Google API Key" field
3. Click "Test Key" to verify it works
4. Click "Update Key" to save and activate Gemini AI

You'll need an API key from [Google AI Studio](https://makersuite.google.com/app/apikey) to complete the setup.

${DISCLAIMER}`,
      })
    }

    // Check if the user query is just a disease name (single word or short phrase)
    const words = userQuery.split(/\s+/).length
    const isPotentialDiseaseName = words <= 5 && !userQuery.includes("?")

    if (isPotentialDiseaseName) {
      // Try to find the disease by exact name first
      let disease = getDiseaseByName(userQuery)

      // If not found by exact name, search for partial matches
      if (!disease) {
        const searchResults = searchDiseases(userQuery)
        if (searchResults.length > 0) {
          disease = searchResults[0] // Take the first match
        }
      }

      // If we found a matching disease, return formatted information
      if (disease) {
        const medicinesText =
          disease.medicines.length > 0
            ? disease.medicines.map((med) => `* ${med}`).join("\n")
            : "No specific medications - consult a healthcare provider for treatment options."

        const symptomsText =
          disease.symptoms && disease.symptoms.length > 0
            ? "\n\n### Common Symptoms:\n" + disease.symptoms.map((sym) => `* ${sym}`).join("\n")
            : ""

        const preventionText =
          disease.prevention && disease.prevention.length > 0
            ? "\n\n### Prevention:\n" + disease.prevention.map((prev) => `* ${prev}`).join("\n")
            : ""

        const complicationsText =
          disease.complications && disease.complications.length > 0
            ? "\n\n### Potential Complications:\n" + disease.complications.map((comp) => `* ${comp}`).join("\n")
            : ""

        const response = `## ${disease.name}

${disease.description}

### Common Medications:
${medicinesText}${symptomsText}${preventionText}${complicationsText}

${DISCLAIMER}`

        return NextResponse.json({
          id: "response-" + Date.now(),
          role: "assistant",
          content: response,
          source: "database",
        })
      }
    }

    // Check if the query is about symptoms
    if (userQuery.includes("symptom") || userQuery.includes("feel") || userQuery.includes("experiencing")) {
      const diseasesWithSymptoms = getDiseasesBySymptom(userQuery)

      if (diseasesWithSymptoms.length > 0) {
        let response = `## Conditions Related to Your Symptoms\n\nBased on the symptoms mentioned, here are some conditions that might be relevant:\n\n`

        diseasesWithSymptoms.slice(0, 3).forEach((disease) => {
          response += `### ${disease.name}\n${disease.description}\n\n**Common Symptoms:**\n`
          if (disease.symptoms && disease.symptoms.length > 0) {
            response += disease.symptoms
              .slice(0, 5)
              .map((s) => `* ${s}`)
              .join("\n")
          }
          response += `\n\n**Common Medications:**\n${disease.medicines.map((m) => `* ${m}`).join("\n")}\n\n`
        })

        response += `Remember that many conditions can have similar symptoms. This information is for educational purposes only.${DISCLAIMER}`

        return NextResponse.json({
          id: "response-" + Date.now(),
          role: "assistant",
          content: response,
          source: "database",
        })
      }
    }

    // Check if the query is about medications
    if (
      userQuery.includes("medicine") ||
      userQuery.includes("medication") ||
      userQuery.includes("drug") ||
      userQuery.includes("treat")
    ) {
      const diseasesWithMedicine = getDiseasesByMedicine(userQuery)

      if (diseasesWithMedicine.length > 0) {
        let response = `## Medications Information\n\nHere's information about the medications you asked about:\n\n`

        diseasesWithMedicine.slice(0, 3).forEach((disease) => {
          response += `### Used for ${disease.name}\n${disease.description}\n\n**Common Medications:**\n${disease.medicines.map((m) => `* ${m}`).join("\n")}\n\n`
        })

        response += `Medications should only be taken as prescribed by a healthcare professional.${DISCLAIMER}`

        return NextResponse.json({
          id: "response-" + Date.now(),
          role: "assistant",
          content: response,
          source: "database",
        })
      }
    }

    // Try to find any relevant diseases as a fallback
    const relevantDiseases = searchDiseases(userQuery)

    if (relevantDiseases.length > 0) {
      let response = `## Related Medical Information\n\nHere's some information that might help with your query:\n\n`

      relevantDiseases.slice(0, 2).forEach((disease) => {
        response += `### ${disease.name}\n${disease.description}\n\n`

        if (disease.symptoms && disease.symptoms.length > 0) {
          response += `**Common Symptoms:**\n${disease.symptoms
            .slice(0, 3)
            .map((s) => `* ${s}`)
            .join("\n")}\n\n`
        }

        response += `**Common Medications:**\n${disease.medicines.map((m) => `* ${m}`).join("\n")}\n\n`
      })

      response += DISCLAIMER

      return NextResponse.json({
        id: "response-" + Date.now(),
        role: "assistant",
        content: response,
        source: "database",
      })
    }

    // If all else fails, provide a generic response with a suggestion to set up Gemini
    const noApiKeyMessage = !apiKey
      ? "\n\nFor more advanced responses, try typing **/setup-gemini** to integrate Google's Gemini AI."
      : ""

    return NextResponse.json({
      id: "response-" + Date.now(),
      role: "assistant",
      content: `I don't have specific information about "${userQuery}". Please try asking about a specific disease, or phrase your question differently.${DISCLAIMER}${noApiKeyMessage}`,
      source: "fallback",
    })
  } catch (error) {
    console.error("Error processing request:", error)
    return NextResponse.json({
      id: `error-${Date.now()}`,
      role: "assistant",
      content: "I'm experiencing technical difficulties. Please try again later.",
    })
  }
}
