import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { apiKey } = await request.json()

    if (!apiKey) {
      return NextResponse.json({ error: "API key is required" }, { status: 400 })
    }

    // Simple validation - check if the key has a reasonable length
    if (apiKey.length < 10) {
      return NextResponse.json({ error: "API key appears to be invalid (too short)" }, { status: 400 })
    }

    // Make a simple test request to the Google API
    try {
      const testUrl = `https://generativelanguage.googleapis.com/v1beta/models?key=${apiKey}`
      const response = await fetch(testUrl)

      if (!response.ok) {
        const errorData = await response.json()
        return NextResponse.json(
          { error: `API key validation failed: ${errorData.error?.message || "Unknown error"}` },
          { status: 400 },
        )
      }

      return NextResponse.json({ success: true })
    } catch (error) {
      return NextResponse.json({ error: "Failed to validate API key with Google API" }, { status: 500 })
    }
  } catch (error) {
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
