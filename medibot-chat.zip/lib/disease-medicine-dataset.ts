export interface DiseaseEntry {
  name: string
  description: string
  medicines: string[]
  category: string
  symptoms?: string[]
  prevention?: string[]
  complications?: string[]
}

export const diseaseDatabase: DiseaseEntry[] = [
  // Cardiovascular Diseases
  {
    name: "Hypertension",
    description:
      "A chronic condition characterized by elevated blood pressure in the arteries, which can lead to heart disease and stroke if untreated.",
    medicines: ["Lisinopril", "Amlodipine"],
    category: "Cardiovascular",
    symptoms: ["Headaches", "Shortness of breath", "Nosebleeds", "Often asymptomatic"],
    prevention: ["Regular exercise", "Low-sodium diet", "Limited alcohol consumption", "Stress management"],
    complications: ["Heart attack", "Stroke", "Heart failure", "Kidney damage"],
  },
  {
    name: "Coronary Artery Disease",
    description:
      "A condition where the major blood vessels that supply the heart become damaged or diseased, often due to plaque buildup.",
    medicines: ["Aspirin", "Atorvastatin"],
    category: "Cardiovascular",
    symptoms: ["Chest pain (angina)", "Shortness of breath", "Pain in arms or shoulders", "Fatigue"],
    prevention: ["Regular exercise", "Heart-healthy diet", "Smoking cessation", "Stress management"],
    complications: ["Heart attack", "Heart failure", "Arrhythmias", "Sudden cardiac death"],
  },
  {
    name: "Heart Failure",
    description:
      "A chronic condition where the heart cannot pump blood effectively to meet the body's needs, causing fatigue and shortness of breath.",
    medicines: ["Furosemide", "Carvedilol"],
    category: "Cardiovascular",
    symptoms: ["Shortness of breath", "Fatigue", "Swelling in legs and ankles", "Rapid heartbeat"],
    prevention: ["Managing blood pressure", "Treating coronary artery disease", "Healthy lifestyle"],
    complications: ["Kidney damage", "Liver damage", "Heart valve problems"],
  },
  {
    name: "Atrial Fibrillation",
    description:
      "An irregular, often rapid heart rate that can increase risk of stroke, heart failure and other heart-related complications.",
    medicines: ["Warfarin", "Metoprolol"],
    category: "Cardiovascular",
    symptoms: ["Palpitations", "Weakness", "Reduced ability to exercise", "Fatigue", "Dizziness"],
    prevention: ["Managing high blood pressure", "Heart-healthy diet", "Avoiding excessive alcohol"],
    complications: ["Stroke", "Heart failure", "Blood clots"],
  },
  {
    name: "Deep Vein Thrombosis",
    description:
      "A blood clot that forms in a deep vein, usually in the legs, which can break loose and cause a pulmonary embolism.",
    medicines: ["Rivaroxaban", "Enoxaparin"],
    category: "Cardiovascular",
    symptoms: ["Leg pain", "Swelling", "Red or discolored skin", "Warmth in affected area"],
    prevention: ["Regular movement", "Compression stockings", "Avoiding long periods of immobility"],
    complications: ["Pulmonary embolism", "Post-thrombotic syndrome", "Chronic venous insufficiency"],
  },
  {
    name: "Peripheral Artery Disease",
    description:
      "A circulatory condition in which narrowed arteries reduce blood flow to the limbs, usually legs, causing pain and mobility issues.",
    medicines: ["Cilostazol", "Clopidogrel"],
    category: "Cardiovascular",
    symptoms: ["Leg pain when walking", "Numbness or weakness in legs", "Cold legs or feet", "Hair loss on legs"],
    prevention: ["Regular exercise", "Smoking cessation", "Healthy diet", "Managing diabetes"],
    complications: ["Critical limb ischemia", "Stroke", "Heart attack", "Tissue death (gangrene)"],
  },
  {
    name: "Aortic Aneurysm",
    description:
      "A bulge or swelling in the aorta, the main blood vessel that runs from the heart down through the chest and abdomen.",
    medicines: ["Beta blockers", "Statins"],
    category: "Cardiovascular",
    symptoms: ["Often asymptomatic", "Deep pain in back or side", "Pulsing sensation near navel"],
    prevention: ["Blood pressure control", "Smoking cessation", "Cholesterol management"],
    complications: ["Rupture", "Dissection", "Blood clots"],
  },

  // Respiratory Diseases
  {
    name: "Asthma",
    description:
      "A chronic condition affecting the airways, characterized by wheezing, shortness of breath, chest tightness, and coughing.",
    medicines: ["Albuterol", "Fluticasone"],
    category: "Respiratory",
    symptoms: ["Wheezing", "Shortness of breath", "Chest tightness", "Coughing, especially at night"],
    prevention: ["Avoiding triggers", "Regular medication", "Allergy management"],
    complications: ["Severe asthma attacks", "Airway remodeling", "Side effects from medications"],
  },
  {
    name: "COPD",
    description:
      "Chronic Obstructive Pulmonary Disease is a progressive lung disease that makes breathing difficult, often caused by smoking.",
    medicines: ["Tiotropium", "Budesonide/Formoterol"],
    category: "Respiratory",
    symptoms: [
      "Shortness of breath",
      "Chronic cough",
      "Wheezing",
      "Chest tightness",
      "Frequent respiratory infections",
    ],
    prevention: ["Smoking cessation", "Avoiding air pollutants", "Vaccination against flu and pneumonia"],
    complications: ["Respiratory infections", "Heart problems", "Lung cancer", "Depression"],
  },
  {
    name: "Pneumonia",
    description:
      "An infection that inflames the air sacs in one or both lungs, which may fill with fluid, causing cough, fever, and difficulty breathing.",
    medicines: ["Azithromycin", "Amoxicillin"],
    category: "Respiratory",
    symptoms: ["Chest pain when breathing", "Cough with phlegm", "Fatigue", "Fever", "Shortness of breath"],
    prevention: ["Vaccination", "Good hygiene", "Not smoking", "Healthy lifestyle"],
    complications: ["Bacteremia", "Lung abscess", "Pleural effusion", "Respiratory failure"],
  },
  {
    name: "Tuberculosis",
    description:
      "A potentially serious infectious bacterial disease that mainly affects the lungs, causing persistent cough, weight loss, and night sweats.",
    medicines: ["Isoniazid", "Rifampin"],
    category: "Respiratory",
    symptoms: ["Coughing for 3+ weeks", "Coughing up blood", "Chest pain", "Weight loss", "Night sweats"],
    prevention: ["BCG vaccine", "Early detection and treatment", "Infection control measures"],
    complications: ["Spinal pain", "Joint damage", "Meningitis", "Liver or kidney problems"],
  },
  {
    name: "Pulmonary Embolism",
    description:
      "A blockage in one of the pulmonary arteries in the lungs, often caused by blood clots that travel from the legs or other parts of the body.",
    medicines: ["Heparin", "Warfarin"],
    category: "Respiratory",
    symptoms: ["Sudden shortness of breath", "Chest pain", "Rapid heartbeat", "Cough with bloody sputum"],
    prevention: ["Avoiding long periods of immobility", "Compression stockings", "Blood thinners when at risk"],
    complications: ["Pulmonary hypertension", "Heart damage", "Death"],
  },
  {
    name: "Bronchitis",
    description:
      "Inflammation of the lining of the bronchial tubes, which carry air to and from the lungs, causing coughing and mucus production.",
    medicines: ["Guaifenesin", "Dextromethorphan"],
    category: "Respiratory",
    symptoms: ["Persistent cough", "Production of mucus", "Fatigue", "Shortness of breath", "Slight fever and chills"],
    prevention: ["Avoiding cigarette smoke", "Getting vaccinated", "Hand washing", "Using masks in polluted areas"],
    complications: ["Pneumonia", "Chronic bronchitis", "Respiratory failure"],
  },
  {
    name: "Cystic Fibrosis",
    description:
      "An inherited disorder that causes severe damage to the lungs, digestive system, and other organs by affecting cells that produce mucus, sweat, and digestive juices.",
    medicines: ["Ivacaftor", "Lumacaftor/Ivacaftor"],
    category: "Respiratory",
    symptoms: [
      "Persistent cough with thick mucus",
      "Wheezing",
      "Recurrent lung infections",
      "Poor growth",
      "Difficulty gaining weight",
    ],
    prevention: ["Genetic counseling (not preventable otherwise)"],
    complications: ["Respiratory failure", "Nutritional deficiencies", "Diabetes", "Liver disease"],
  },
  {
    name: "Pulmonary Fibrosis",
    description:
      "A lung disease that occurs when lung tissue becomes damaged and scarred, making it difficult for the lungs to work properly.",
    medicines: ["Pirfenidone", "Nintedanib"],
    category: "Respiratory",
    symptoms: ["Shortness of breath", "Dry cough", "Fatigue", "Unexplained weight loss", "Aching muscles and joints"],
    prevention: [
      "Avoiding smoking",
      "Avoiding occupational and environmental exposures",
      "Wearing protective equipment",
    ],
    complications: ["Respiratory failure", "Pulmonary hypertension", "Right-sided heart failure", "Lung cancer"],
  },

  // Gastrointestinal Diseases
  {
    name: "GERD",
    description:
      "Gastroesophageal Reflux Disease is a digestive disorder that affects the lower esophageal sphincter, causing heartburn and acid reflux.",
    medicines: ["Omeprazole", "Famotidine"],
    category: "Gastrointestinal",
    symptoms: ["Heartburn", "Regurgitation", "Difficulty swallowing", "Chest pain", "Sensation of a lump in throat"],
    prevention: ["Weight management", "Avoiding trigger foods", "Eating smaller meals", "Not lying down after eating"],
    complications: ["Esophagitis", "Esophageal stricture", "Barrett's esophagus", "Esophageal cancer"],
  },
  {
    name: "Peptic Ulcer",
    description:
      "An open sore that develops on the inside lining of the stomach, upper small intestine, or esophagus, causing stomach pain.",
    medicines: ["Omeprazole", "Clarithromycin"],
    category: "Gastrointestinal",
    symptoms: ["Burning stomach pain", "Feeling of fullness or bloating", "Intolerance to fatty foods", "Heartburn"],
    prevention: ["H. pylori testing and treatment", "Limiting NSAIDs", "Avoiding smoking", "Limiting alcohol"],
    complications: ["Internal bleeding", "Perforation", "Obstruction", "Peritonitis"],
  },
  {
    name: "Crohn's Disease",
    description:
      "A type of inflammatory bowel disease that causes inflammation in the digestive tract, leading to abdominal pain, severe diarrhea, and malnutrition.",
    medicines: ["Infliximab", "Azathioprine"],
    category: "Gastrointestinal",
    symptoms: [
      "Diarrhea",
      "Abdominal pain and cramping",
      "Blood in stool",
      "Fatigue",
      "Reduced appetite and weight loss",
    ],
    prevention: ["No known prevention", "Smoking cessation may help"],
    complications: ["Bowel obstruction", "Ulcers", "Fistulas", "Anal fissures", "Malnutrition"],
  },
  {
    name: "Ulcerative Colitis",
    description:
      "A chronic inflammatory bowel disease that causes inflammation and ulcers in the digestive tract, primarily affecting the colon and rectum.",
    medicines: ["Mesalamine", "Prednisone"],
    category: "Gastrointestinal",
    symptoms: [
      "Diarrhea with blood or pus",
      "Abdominal pain and cramping",
      "Rectal pain",
      "Urgency to defecate",
      "Weight loss",
    ],
    prevention: ["No known prevention"],
    complications: ["Severe bleeding", "Colon perforation", "Severe dehydration", "Increased risk of colon cancer"],
  },
  {
    name: "Irritable Bowel Syndrome",
    description:
      "A common disorder affecting the large intestine, causing abdominal pain, cramping, bloating, gas, diarrhea, and constipation.",
    medicines: ["Dicyclomine", "Loperamide"],
    category: "Gastrointestinal",
    symptoms: ["Abdominal pain or cramping", "Bloating", "Gas", "Diarrhea or constipation", "Mucus in stool"],
    prevention: ["Stress management", "Dietary changes", "Regular exercise"],
    complications: ["Poor quality of life", "Mood disorders"],
  },
  {
    name: "Celiac Disease",
    description:
      "An immune reaction to eating gluten, a protein found in wheat, barley, and rye, damaging the small intestine's lining and preventing nutrient absorption.",
    medicines: ["No specific medications - strict gluten-free diet is the treatment"],
    category: "Gastrointestinal",
    symptoms: ["Diarrhea", "Fatigue", "Weight loss", "Bloating and gas", "Abdominal pain", "Nausea and vomiting"],
    prevention: ["No prevention - gluten-free diet manages the condition"],
    complications: ["Malnutrition", "Bone weakening", "Infertility", "Neurological problems", "Cancer"],
  },
  {
    name: "Diverticulitis",
    description:
      "Inflammation or infection in one or more small pouches (diverticula) that can form in the digestive tract, most commonly in the colon.",
    medicines: ["Ciprofloxacin", "Metronidazole"],
    category: "Gastrointestinal",
    symptoms: ["Pain in lower left abdomen", "Fever", "Nausea", "Constipation or diarrhea", "Rectal bleeding"],
    prevention: ["High-fiber diet", "Regular exercise", "Drinking plenty of fluids", "Avoiding NSAIDs"],
    complications: ["Abscess", "Perforation", "Fistula", "Intestinal obstruction", "Peritonitis"],
  },
  {
    name: "Gallstones",
    description:
      "Hardened deposits of digestive fluid that can form in the gallbladder, causing pain and potential complications.",
    medicines: ["Ursodiol", "Pain relievers"],
    category: "Gastrointestinal",
    symptoms: [
      "Sudden pain in upper right abdomen",
      "Pain in right shoulder",
      "Nausea",
      "Vomiting",
      "High fever with chills",
    ],
    prevention: ["Maintaining healthy weight", "Low-fat diet", "Regular meals", "Exercise"],
    complications: ["Gallbladder inflammation", "Bile duct inflammation", "Pancreatitis"],
  },

  // Neurological Diseases
  {
    name: "Alzheimer's Disease",
    description:
      "A progressive disorder that causes brain cells to degenerate and die, leading to memory loss and cognitive decline.",
    medicines: ["Donepezil", "Memantine"],
    category: "Neurological",
    symptoms: [
      "Memory loss",
      "Difficulty with problem-solving",
      "Confusion with time or place",
      "Changes in mood and personality",
    ],
    prevention: ["Physical exercise", "Mental stimulation", "Social engagement", "Heart-healthy diet"],
    complications: ["Inability to communicate", "Malnutrition", "Infection", "Death"],
  },
  {
    name: "Parkinson's Disease",
    description:
      "A progressive nervous system disorder that affects movement, causing tremors, stiffness, and difficulty with balance and coordination.",
    medicines: ["Levodopa", "Carbidopa"],
    category: "Neurological",
    symptoms: [
      "Tremor",
      "Slowed movement",
      "Rigid muscles",
      "Impaired posture and balance",
      "Loss of automatic movements",
    ],
    prevention: ["No known prevention", "Regular exercise may reduce risk"],
    complications: ["Cognitive problems", "Depression", "Sleep disorders", "Eating problems", "Bladder problems"],
  },
  {
    name: "Multiple Sclerosis",
    description:
      "A potentially disabling disease of the brain and spinal cord where the immune system attacks the protective sheath that covers nerve fibers.",
    medicines: ["Interferon beta-1a", "Fingolimod"],
    category: "Neurological",
    symptoms: [
      "Numbness or weakness in limbs",
      "Electric-shock sensations",
      "Tremor",
      "Vision problems",
      "Slurred speech",
    ],
    prevention: ["No known prevention", "Vitamin D may have protective effects"],
    complications: ["Muscle stiffness or spasms", "Paralysis", "Sexual dysfunction", "Depression", "Epilepsy"],
  },
  {
    name: "Epilepsy",
    description:
      "A central nervous system disorder in which brain activity becomes abnormal, causing seizures or periods of unusual behavior and sensations.",
    medicines: ["Lamotrigine", "Levetiracetam"],
    category: "Neurological",
    symptoms: [
      "Temporary confusion",
      "Staring spells",
      "Uncontrollable jerking movements",
      "Loss of consciousness",
      "Fear or anxiety",
    ],
    prevention: ["Preventing head injuries", "Reducing fevers in children", "Prenatal care"],
    complications: [
      "Status epilepticus",
      "Sudden unexpected death in epilepsy",
      "Drowning risks",
      "Emotional health issues",
    ],
  },
  {
    name: "Migraine",
    description:
      "A neurological condition that causes severe, debilitating headaches often accompanied by nausea, vomiting, and sensitivity to light and sound.",
    medicines: ["Sumatriptan", "Propranolol"],
    category: "Neurological",
    symptoms: ["Throbbing headache", "Nausea", "Vomiting", "Sensitivity to light and sound", "Visual disturbances"],
    prevention: ["Identifying and avoiding triggers", "Regular sleep schedule", "Stress management", "Regular meals"],
    complications: ["Chronic migraine", "Status migrainosus", "Persistent aura", "Migrainous infarction"],
  },
  {
    name: "Amyotrophic Lateral Sclerosis",
    description:
      "A progressive nervous system disease that affects nerve cells in the brain and spinal cord, causing loss of muscle control.",
    medicines: ["Riluzole", "Edaravone"],
    category: "Neurological",
    symptoms: [
      "Difficulty walking",
      "Tripping and falling",
      "Weakness in legs, feet or ankles",
      "Slurred speech",
      "Trouble swallowing",
    ],
    prevention: ["No known prevention"],
    complications: ["Breathing problems", "Speaking problems", "Eating problems", "Dementia"],
  },
  {
    name: "Huntington's Disease",
    description:
      "An inherited condition that causes the progressive breakdown of nerve cells in the brain, affecting movement, cognition, and psychiatric health.",
    medicines: ["Tetrabenazine", "Antipsychotics"],
    category: "Neurological",
    symptoms: [
      "Involuntary jerking movements",
      "Muscle problems",
      "Slow or abnormal eye movements",
      "Difficulty with speech",
      "Cognitive decline",
    ],
    prevention: ["Genetic counseling for those at risk"],
    complications: ["Depression", "Difficulty swallowing", "Pneumonia", "Heart disease"],
  },
  {
    name: "Stroke",
    description:
      "A medical emergency that occurs when blood flow to the brain is interrupted, causing brain cells to die from lack of oxygen.",
    medicines: ["Alteplase", "Aspirin"],
    category: "Neurological",
    symptoms: [
      "Sudden numbness or weakness in face/limbs",
      "Confusion",
      "Trouble speaking",
      "Vision problems",
      "Severe headache",
    ],
    prevention: ["Blood pressure control", "Not smoking", "Physical activity", "Healthy diet", "Limited alcohol"],
    complications: ["Paralysis", "Speech difficulties", "Memory loss", "Emotional problems", "Pain"],
  },

  // Endocrine Diseases
  {
    name: "Type 1 Diabetes",
    description:
      "An autoimmune condition where the pancreas produces little or no insulin, requiring daily insulin administration to regulate blood sugar.",
    medicines: ["Insulin Glargine", "Insulin Lispro"],
    category: "Endocrine",
    symptoms: ["Increased thirst", "Frequent urination", "Extreme hunger", "Unintended weight loss", "Fatigue"],
    prevention: ["No known prevention"],
    complications: ["Heart disease", "Nerve damage", "Kidney damage", "Eye damage", "Foot damage"],
  },
  {
    name: "Type 2 Diabetes",
    description:
      "A chronic condition that affects the way the body processes blood sugar, characterized by insulin resistance or insufficient insulin production.",
    medicines: ["Metformin", "Empagliflozin"],
    category: "Endocrine",
    symptoms: ["Increased thirst", "Frequent urination", "Increased hunger", "Fatigue", "Blurred vision"],
    prevention: ["Healthy weight", "Regular exercise", "Healthy diet", "Not smoking"],
    complications: ["Heart disease", "Nerve damage", "Kidney damage", "Eye damage", "Foot damage"],
  },
  {
    name: "Hypothyroidism",
    description:
      "A condition where the thyroid gland doesn't produce enough thyroid hormone, causing fatigue, cold sensitivity, and weight gain.",
    medicines: ["Levothyroxine"],
    category: "Endocrine",
    symptoms: ["Fatigue", "Increased sensitivity to cold", "Constipation", "Dry skin", "Weight gain", "Puffy face"],
    prevention: ["Iodine in diet", "Monitoring if at high risk"],
    complications: ["Goiter", "Heart problems", "Mental health issues", "Myxedema", "Birth defects"],
  },
  {
    name: "Hyperthyroidism",
    description:
      "A condition where the thyroid gland produces too much thyroid hormone, causing weight loss, rapid heartbeat, and nervousness.",
    medicines: ["Methimazole", "Propranolol"],
    category: "Endocrine",
    symptoms: ["Weight loss", "Rapid heartbeat", "Increased appetite", "Nervousness", "Tremors", "Heat sensitivity"],
    prevention: ["No specific prevention"],
    complications: ["Heart problems", "Brittle bones", "Eye problems", "Thyrotoxic crisis"],
  },
  {
    name: "Cushing's Syndrome",
    description:
      "A disorder that occurs when the body is exposed to high levels of cortisol for a long time, causing weight gain and fatty tissue deposits.",
    medicines: ["Ketoconazole", "Mifepristone"],
    category: "Endocrine",
    symptoms: ["Weight gain", "Fatty tissue deposits", "Pink or purple stretch marks", "Thinning skin", "Fatigue"],
    prevention: ["Careful use of corticosteroid medications"],
    complications: ["Bone loss", "High blood pressure", "Type 2 diabetes", "Frequent infections"],
  },
  {
    name: "Addison's Disease",
    description:
      "A disorder that occurs when the adrenal glands don't produce enough hormones, causing fatigue, weight loss, and low blood pressure.",
    medicines: ["Hydrocortisone", "Fludrocortisone"],
    category: "Endocrine",
    symptoms: ["Fatigue", "Weight loss", "Low blood pressure", "Salt craving", "Hyperpigmentation"],
    prevention: ["No known prevention"],
    complications: ["Addisonian crisis", "Cardiovascular disease", "Severe hypoglycemia"],
  },
  {
    name: "Acromegaly",
    description:
      "A hormonal disorder that develops when the pituitary gland produces too much growth hormone during adulthood, causing enlarged hands, feet, and facial features.",
    medicines: ["Octreotide", "Pegvisomant"],
    category: "Endocrine",
    symptoms: ["Enlarged hands and feet", "Coarsened facial features", "Sweating", "Fatigue", "Joint pain"],
    prevention: ["No known prevention"],
    complications: ["Heart disease", "Diabetes", "Sleep apnea", "Arthritis", "Goiter"],
  },

  // Infectious Diseases
  {
    name: "COVID-19",
    description:
      "A highly contagious respiratory illness caused by the SARS-CoV-2 virus, characterized by fever, cough, and shortness of breath.",
    medicines: ["Paxlovid", "Remdesivir"],
    category: "Infectious",
    symptoms: ["Fever", "Cough", "Shortness of breath", "Fatigue", "Loss of taste or smell"],
    prevention: ["Vaccination", "Hand hygiene", "Mask wearing", "Physical distancing"],
    complications: [
      "Pneumonia",
      "Respiratory failure",
      "Acute respiratory distress syndrome",
      "Long COVID",
      "Multi-organ failure",
    ],
  },
  {
    name: "Influenza",
    description:
      "A contagious respiratory illness caused by influenza viruses, characterized by fever, cough, sore throat, body aches, and fatigue.",
    medicines: ["Oseltamivir", "Baloxavir"],
    category: "Infectious",
    symptoms: ["Fever", "Cough", "Sore throat", "Muscle aches", "Fatigue", "Headache"],
    prevention: ["Annual vaccination", "Hand hygiene", "Avoiding close contact with sick people"],
    complications: ["Pneumonia", "Bronchitis", "Sinus infections", "Ear infections", "Worsening of chronic conditions"],
  },
  {
    name: "HIV/AIDS",
    description:
      "A chronic viral infection that attacks the immune system, making the body vulnerable to other infections and diseases.",
    medicines: ["Bictegravir/Emtricitabine/Tenofovir", "Dolutegravir"],
    category: "Infectious",
    symptoms: ["Fever", "Fatigue", "Swollen lymph nodes", "Sore throat", "Rash", "Night sweats"],
    prevention: ["Safe sex practices", "Pre-exposure prophylaxis (PrEP)", "Not sharing needles"],
    complications: ["Opportunistic infections", "Certain cancers", "Wasting syndrome", "Neurological complications"],
  },
  {
    name: "Hepatitis C",
    description:
      "A viral infection that causes liver inflammation, sometimes leading to serious liver damage, often spread through contaminated blood.",
    medicines: ["Sofosbuvir/Velpatasvir", "Glecaprevir/Pibrentasvir"],
    category: "Infectious",
    symptoms: ["Fatigue", "Bleeding easily", "Bruising easily", "Jaundice", "Dark urine", "Itchy skin"],
    prevention: ["Avoiding sharing needles", "Practicing safe sex", "Screening blood products"],
    complications: ["Cirrhosis", "Liver cancer", "Liver failure", "Portal hypertension"],
  },
  {
    name: "Malaria",
    description:
      "A serious disease caused by a parasite that commonly infects a certain type of mosquito, causing high fevers, shaking chills, and flu-like illness.",
    medicines: ["Artemether/Lumefantrine", "Chloroquine"],
    category: "Infectious",
    symptoms: ["Fever", "Chills", "Headache", "Nausea and vomiting", "Muscle pain", "Fatigue"],
    prevention: ["Antimalarial drugs", "Mosquito nets", "Insect repellent", "Appropriate clothing"],
    complications: ["Cerebral malaria", "Breathing problems", "Organ failure", "Severe anemia", "Low blood sugar"],
  },
  {
    name: "Lyme Disease",
    description:
      "An infectious disease caused by the bacterium Borrelia burgdorferi, spread by ticks, causing rash, fever, headache, and fatigue.",
    medicines: ["Doxycycline", "Amoxicillin"],
    category: "Infectious",
    symptoms: ["Bull's-eye rash", "Fever", "Chills", "Fatigue", "Body aches", "Headache", "Neck stiffness"],
    prevention: [
      "Avoiding tick-infested areas",
      "Using insect repellent",
      "Removing ticks promptly",
      "Protective clothing",
    ],
    complications: ["Joint pain", "Neurological problems", "Heart problems", "Eye inflammation", "Liver inflammation"],
  },
  {
    name: "Ebola",
    description:
      "A rare but severe and often fatal illness caused by Ebola virus infection, leading to fever, body aches, and internal bleeding.",
    medicines: ["Inmazeb", "Ebanga"],
    category: "Infectious",
    symptoms: ["Fever", "Severe headache", "Muscle pain", "Fatigue", "Diarrhea", "Vomiting", "Unexplained bleeding"],
    prevention: [
      "Avoiding contact with infected people",
      "Proper hygiene",
      "Avoiding bush meat",
      "Vaccination for high-risk groups",
    ],
    complications: ["Severe bleeding", "Multiple organ failure", "Death"],
  },
  {
    name: "Tuberculosis",
    description:
      "A potentially serious infectious bacterial disease that mainly affects the lungs, causing persistent cough, weight loss, and night sweats.",
    medicines: ["Isoniazid", "Rifampin"],
    category: "Infectious",
    symptoms: ["Coughing for 3+ weeks", "Coughing up blood", "Chest pain", "Weight loss", "Night sweats", "Fatigue"],
    prevention: ["BCG vaccine", "Early detection and treatment", "Infection control measures"],
    complications: ["Spinal pain", "Joint damage", "Meningitis", "Liver or kidney problems", "Heart disorders"],
  },

  // Mental Health Disorders
  {
    name: "Depression",
    description:
      "A mood disorder that causes a persistent feeling of sadness and loss of interest, affecting how you feel, think, and handle daily activities.",
    medicines: ["Sertraline", "Escitalopram"],
    category: "Mental Health",
    symptoms: [
      "Persistent sadness",
      "Loss of interest in activities",
      "Changes in appetite",
      "Sleep problems",
      "Fatigue",
      "Feelings of worthlessness",
    ],
    prevention: ["Stress management", "Regular exercise", "Social connections", "Sleep hygiene", "Seeking help early"],
    complications: ["Anxiety", "Substance abuse", "Physical health problems", "Suicidal thoughts", "Self-harm"],
  },
  {
    name: "Anxiety Disorder",
    description:
      "A mental health disorder characterized by feelings of worry, anxiety, or fear that are strong enough to interfere with daily activities.",
    medicines: ["Escitalopram", "Buspirone"],
    category: "Mental Health",
    symptoms: [
      "Excessive worry",
      "Restlessness",
      "Fatigue",
      "Difficulty concentrating",
      "Irritability",
      "Sleep problems",
    ],
    prevention: ["Stress management", "Regular exercise", "Limiting caffeine and alcohol", "Relaxation techniques"],
    complications: ["Depression", "Substance abuse", "Social isolation", "Physical health problems"],
  },
  {
    name: "Bipolar Disorder",
    description:
      "A mental health condition that causes extreme mood swings that include emotional highs (mania or hypomania) and lows (depression).",
    medicines: ["Lithium", "Lamotrigine"],
    category: "Mental Health",
    symptoms: [
      "Mood swings",
      "Elevated mood",
      "Decreased need for sleep",
      "Racing thoughts",
      "Poor decision-making",
      "Depressive episodes",
    ],
    prevention: ["No known prevention", "Early intervention can help manage symptoms"],
    complications: [
      "Substance abuse",
      "Suicide",
      "Financial problems",
      "Relationship difficulties",
      "Poor work or school performance",
    ],
  },
  {
    name: "Schizophrenia",
    description:
      "A chronic brain disorder that affects how a person thinks, feels, and behaves, often resulting in hallucinations, delusions, and disordered thinking.",
    medicines: ["Risperidone", "Olanzapine"],
    category: "Mental Health",
    symptoms: [
      "Hallucinations",
      "Delusions",
      "Disorganized thinking",
      "Abnormal motor behavior",
      "Lack of emotion",
      "Social withdrawal",
    ],
    prevention: ["No known prevention", "Early treatment may help outcomes"],
    complications: ["Suicide", "Anxiety disorders", "Depression", "Substance abuse", "Social isolation"],
  },
  {
    name: "ADHD",
    description:
      "Attention-Deficit/Hyperactivity Disorder is a neurodevelopmental disorder characterized by inattention, hyperactivity, and impulsivity.",
    medicines: ["Methylphenidate", "Atomoxetine"],
    category: "Mental Health",
    symptoms: [
      "Difficulty paying attention",
      "Hyperactivity",
      "Impulsivity",
      "Disorganization",
      "Poor time management",
      "Forgetfulness",
    ],
    prevention: ["No known prevention", "Early intervention can help manage symptoms"],
    complications: [
      "Academic difficulties",
      "Employment problems",
      "Relationship challenges",
      "Substance abuse",
      "Low self-esteem",
    ],
  },
  {
    name: "PTSD",
    description:
      "Post-Traumatic Stress Disorder is a mental health condition triggered by experiencing or witnessing a terrifying event, causing flashbacks, nightmares, and severe anxiety.",
    medicines: ["Sertraline", "Prazosin"],
    category: "Mental Health",
    symptoms: [
      "Flashbacks",
      "Nightmares",
      "Severe anxiety",
      "Uncontrollable thoughts about the event",
      "Avoidance behaviors",
      "Negative changes in thinking and mood",
    ],
    prevention: ["Early treatment after trauma", "Social support", "Learning coping mechanisms"],
    complications: ["Depression", "Substance abuse", "Eating disorders", "Suicidal thoughts and behavior"],
  },
  {
    name: "OCD",
    description:
      "Obsessive-Compulsive Disorder is characterized by unreasonable thoughts and fears (obsessions) that lead to repetitive behaviors (compulsions).",
    medicines: ["Fluoxetine", "Clomipramine"],
    category: "Mental Health",
    symptoms: [
      "Unwanted repetitive thoughts",
      "Fear of contamination",
      "Need for symmetry",
      "Excessive cleaning",
      "Checking behaviors",
      "Counting rituals",
    ],
    prevention: ["No known prevention", "Early intervention can help manage symptoms"],
    complications: ["Depression", "Anxiety", "Eating disorders", "Substance abuse", "Suicidal thoughts"],
  },

  // Autoimmune Diseases
  {
    name: "Rheumatoid Arthritis",
    description:
      "A chronic inflammatory disorder affecting many joints, including those in the hands and feet, causing painful swelling that can lead to bone erosion.",
    medicines: ["Methotrexate", "Adalimumab"],
    category: "Autoimmune",
    symptoms: ["Joint pain", "Joint swelling", "Joint stiffness", "Fatigue", "Fever", "Weight loss"],
    prevention: ["No known prevention", "Not smoking may reduce risk"],
    complications: [
      "Osteoporosis",
      "Rheumatoid nodules",
      "Dry eyes and mouth",
      "Infections",
      "Abnormal body composition",
    ],
  },
  {
    name: "Lupus",
    description:
      "A systemic autoimmune disease that occurs when the body's immune system attacks its own tissues and organs, causing inflammation and tissue damage.",
    medicines: ["Hydroxychloroquine", "Belimumab"],
    category: "Autoimmune",
    symptoms: [
      "Fatigue",
      "Joint pain",
      "Butterfly-shaped rash on face",
      "Skin lesions",
      "Fever",
      "Shortness of breath",
    ],
    prevention: ["No known prevention", "Sun protection may help prevent flares"],
    complications: [
      "Kidney damage",
      "Brain and central nervous system damage",
      "Blood problems",
      "Heart problems",
      "Lung damage",
    ],
  },
  {
    name: "Psoriasis",
    description:
      "A skin disease that causes red, itchy scaly patches, most commonly on the knees, elbows, trunk and scalp, due to an overactive immune system.",
    medicines: ["Methotrexate", "Adalimumab"],
    category: "Autoimmune",
    symptoms: [
      "Red patches of skin with silvery scales",
      "Dry, cracked skin that may bleed",
      "Itching",
      "Burning",
      "Soreness",
      "Thickened nails",
    ],
    prevention: ["No known prevention", "Stress management and avoiding triggers may help prevent flares"],
    complications: ["Psoriatic arthritis", "Eye conditions", "Obesity", "Type 2 diabetes", "High blood pressure"],
  },
  {
    name: "Celiac Disease",
    description:
      "An immune reaction to eating gluten, a protein found in wheat, barley, and rye, damaging the small intestine's lining and preventing nutrient absorption.",
    medicines: ["No specific medications - strict gluten-free diet is the treatment"],
    category: "Autoimmune",
    symptoms: ["Diarrhea", "Fatigue", "Weight loss", "Bloating", "Anemia", "Bone or joint pain"],
    prevention: ["No known prevention", "Early diagnosis can prevent complications"],
    complications: ["Malnutrition", "Bone weakening", "Infertility", "Neurological problems", "Cancer"],
  },
  {
    name: "Graves' Disease",
    description:
      "An immune system disorder that results in the overproduction of thyroid hormones, causing symptoms like anxiety, tremors, and weight loss.",
    medicines: ["Methimazole", "Propranolol"],
    category: "Autoimmune",
    symptoms: [
      "Anxiety",
      "Hand tremors",
      "Heat sensitivity",
      "Weight loss",
      "Bulging eyes",
      "Thick, red skin on shins or tops of feet",
    ],
    prevention: ["No known prevention"],
    complications: ["Thyroid storm", "Heart problems", "Brittle bones", "Eye problems"],
  },
  {
    name: "Multiple Sclerosis",
    description:
      "A potentially disabling disease of the brain and spinal cord where the immune system attacks the protective sheath that covers nerve fibers.",
    medicines: ["Interferon beta-1a", "Fingolimod"],
    category: "Autoimmune",
    symptoms: [
      "Numbness or weakness in limbs",
      "Electric-shock sensations",
      "Tremor",
      "Vision problems",
      "Slurred speech",
    ],
    prevention: ["No known prevention", "Vitamin D may have protective effects"],
    complications: ["Muscle stiffness or spasms", "Paralysis", "Sexual dysfunction", "Depression", "Epilepsy"],
  },
  {
    name: "Type 1 Diabetes",
    description:
      "An autoimmune condition where the pancreas produces little or no insulin, requiring daily insulin administration to regulate blood sugar.",
    medicines: ["Insulin Glargine", "Insulin Lispro"],
    category: "Autoimmune",
    symptoms: ["Increased thirst", "Frequent urination", "Extreme hunger", "Unintended weight loss", "Fatigue"],
    prevention: ["No known prevention"],
    complications: ["Heart disease", "Nerve damage", "Kidney damage", "Eye damage", "Foot damage"],
  },
  {
    name: "Sjogren's Syndrome",
    description:
      "An immune system disorder characterized by dry eyes and dry mouth, often accompanying other immune system disorders like rheumatoid arthritis and lupus.",
    medicines: ["Pilocarpine", "Cevimeline"],
    category: "Autoimmune",
    symptoms: ["Dry eyes", "Dry mouth", "Joint pain", "Swelling", "Stiffness", "Skin rashes", "Vaginal dryness"],
    prevention: ["No known prevention"],
    complications: ["Dental cavities", "Eye infections", "Vision problems", "Lung problems", "Lymphoma"],
  },

  // Rare Diseases
  {
    name: "Cystic Fibrosis",
    description:
      "An inherited disorder that causes severe damage to the lungs, digestive system, and other organs by affecting cells that produce mucus, sweat, and digestive juices.",
    medicines: ["Ivacaftor", "Lumacaftor/Ivacaftor"],
    category: "Rare",
    symptoms: [
      "Persistent cough with thick mucus",
      "Wheezing",
      "Recurrent lung infections",
      "Poor growth",
      "Difficulty gaining weight",
    ],
    prevention: ["Genetic counseling (not preventable otherwise)"],
    complications: ["Respiratory failure", "Nutritional deficiencies", "Diabetes", "Liver disease"],
  },
  {
    name: "Huntington's Disease",
    description:
      "An inherited condition that causes the progressive breakdown of nerve cells in the brain, affecting movement, cognition, and psychiatric health.",
    medicines: ["Tetrabenazine", "Antipsychotics"],
    category: "Rare",
    symptoms: [
      "Involuntary jerking movements",
      "Muscle problems",
      "Slow or abnormal eye movements",
      "Difficulty with speech",
      "Cognitive decline",
    ],
    prevention: ["Genetic counseling for those at risk"],
    complications: ["Depression", "Difficulty swallowing", "Pneumonia", "Heart disease"],
  },
  {
    name: "Amyotrophic Lateral Sclerosis",
    description:
      "A progressive nervous system disease that affects nerve cells in the brain and spinal cord, causing loss of muscle control.",
    medicines: ["Riluzole", "Edaravone"],
    category: "Rare",
    symptoms: [
      "Difficulty walking",
      "Tripping and falling",
      "Weakness in legs, feet or ankles",
      "Slurred speech",
      "Trouble swallowing",
    ],
    prevention: ["No known prevention"],
    complications: ["Breathing problems", "Speaking problems", "Eating problems", "Dementia"],
  },
  {
    name: "Sickle Cell Disease",
    description:
      "An inherited red blood cell disorder where red blood cells become hard, sticky and C-shaped, causing pain and other serious problems.",
    medicines: ["Hydroxyurea", "Voxelotor"],
    category: "Rare",
    symptoms: [
      "Anemia",
      "Episodes of pain",
      "Swelling of hands and feet",
      "Frequent infections",
      "Delayed growth",
      "Vision problems",
    ],
    prevention: ["Genetic counseling (not preventable otherwise)"],
    complications: ["Stroke", "Acute chest syndrome", "Pulmonary hypertension", "Organ damage", "Blindness"],
  },
  {
    name: "Hemophilia",
    description:
      "A rare disorder in which blood doesn't clot normally because it lacks sufficient blood-clotting proteins, causing excessive bleeding.",
    medicines: ["Factor VIII concentrate", "Factor IX concentrate"],
    category: "Rare",
    symptoms: ["Excessive bleeding", "Easy bruising", "Bleeding into joints", "Blood in urine or stool", "Nosebleeds"],
    prevention: ["Genetic counseling (not preventable otherwise)"],
    complications: [
      "Deep internal bleeding",
      "Joint damage",
      "Infection",
      "Adverse reaction to clotting factor treatment",
    ],
  },
  {
    name: "Marfan Syndrome",
    description:
      "A genetic disorder that affects the body's connective tissue, which provides strength and flexibility to structures throughout the body.",
    medicines: ["Beta blockers", "Angiotensin receptor blockers"],
    category: "Rare",
    symptoms: [
      "Tall, slender build",
      "Long arms, legs and fingers",
      "Heart murmurs",
      "Extreme nearsightedness",
      "Curved spine",
    ],
    prevention: ["Genetic counseling (not preventable otherwise)"],
    complications: ["Aortic aneurysm and dissection", "Heart valve problems", "Eye problems", "Breathing problems"],
  },
  {
    name: "Gaucher Disease",
    description:
      "A rare genetic disorder in which a fatty substance (glucocerebroside) accumulates in cells and certain organs, causing a variety of symptoms.",
    medicines: ["Imiglucerase", "Eliglustat"],
    category: "Rare",
    symptoms: ["Enlarged liver and spleen", "Anemia", "Easy bruising", "Fatigue", "Bone pain", "Bone fractures"],
    prevention: ["Genetic counseling (not preventable otherwise)"],
    complications: ["Bone disease", "Blood disorders", "Liver and spleen enlargement", "Lung disease"],
  },
  {
    name: "Fabry Disease",
    description:
      "A rare genetic disorder that prevents the body from breaking down a specific type of fat, leading to its buildup in blood vessels and tissues.",
    medicines: ["Agalsidase beta", "Migalastat"],
    category: "Rare",
    symptoms: [
      "Pain in hands and feet",
      "Dark red spots on skin",
      "Decreased sweating",
      "Cloudiness of the eye",
      "Hearing problems",
    ],
    prevention: ["Genetic counseling (not preventable otherwise)"],
    complications: ["Heart problems", "Kidney damage", "Stroke", "Skin abnormalities"],
  },

  // Skin Conditions
  {
    name: "Acne",
    description:
      "A skin condition that occurs when hair follicles become plugged with oil and dead skin cells, causing whiteheads, blackheads, or pimples.",
    medicines: ["Benzoyl Peroxide", "Tretinoin"],
    category: "Dermatological",
    symptoms: ["Whiteheads", "Blackheads", "Pimples", "Nodules", "Cystic lesions"],
    prevention: ["Regular cleansing", "Avoiding oil-based products", "Not touching face", "Healthy diet"],
    complications: ["Scarring", "Skin discoloration", "Psychological distress"],
  },
  {
    name: "Eczema",
    description:
      "A condition that makes your skin red and itchy, often appearing on the hands, feet, ankles, wrists, neck, upper chest, eyelids, and inside the elbows and knees.",
    medicines: ["Hydrocortisone cream", "Tacrolimus ointment"],
    category: "Dermatological",
    symptoms: ["Dry skin", "Itching", "Red rashes", "Bumps on skin", "Thickened skin", "Sensitive skin"],
    prevention: [
      "Moisturizing regularly",
      "Identifying and avoiding triggers",
      "Taking shorter baths/showers",
      "Using gentle soaps",
    ],
    complications: ["Asthma and hay fever", "Chronic itchy, scaly skin", "Skin infections", "Sleep problems"],
  },
  {
    name: "Rosacea",
    description:
      "A chronic skin condition that causes facial redness, visible blood vessels, and sometimes small, red, pus-filled bumps, primarily affecting the face.",
    medicines: ["Metronidazole gel", "Azelaic acid"],
    category: "Dermatological",
    symptoms: ["Facial redness", "Visible blood vessels", "Swollen red bumps", "Eye problems", "Enlarged nose"],
    prevention: ["Avoiding triggers", "Sun protection", "Gentle skin care"],
    complications: ["Permanent skin redness", "Eye problems", "Rhinophyma (enlarged nose)"],
  },
  {
    name: "Psoriasis",
    description:
      "A skin disease that causes red, itchy scaly patches, most commonly on the knees, elbows, trunk and scalp, due to an overactive immune system.",
    medicines: ["Calcipotriene", "Clobetasol"],
    category: "Dermatological",
    symptoms: [
      "Red patches of skin with silvery scales",
      "Dry, cracked skin that may bleed",
      "Itching",
      "Burning",
      "Soreness",
      "Thickened nails",
    ],
    prevention: ["No known prevention", "Stress management and avoiding triggers may help prevent flares"],
    complications: ["Psoriatic arthritis", "Eye conditions", "Obesity", "Type 2 diabetes", "High blood pressure"],
  },
  {
    name: "Melanoma",
    description:
      "The most serious type of skin cancer, developing in the cells that produce melanin, the pigment that gives skin its color.",
    medicines: ["Pembrolizumab", "Nivolumab"],
    category: "Dermatological",
    symptoms: [
      "New, unusual growth or change in existing mole",
      "Asymmetrical moles",
      "Irregular borders",
      "Color changes",
      "Diameter larger than 6mm",
      "Evolving appearance",
    ],
    prevention: ["Sun protection", "Avoiding tanning beds", "Regular skin checks", "Knowing your risk factors"],
    complications: ["Metastasis to other organs", "Recurrence"],
  },
  {
    name: "Vitiligo",
    description:
      "A disease that causes the loss of skin color in patches due to destruction of pigment-producing cells (melanocytes).",
    medicines: ["Tacrolimus ointment", "Corticosteroid creams"],
    category: "Dermatological",
    symptoms: [
      "Patchy loss of skin color",
      "Premature whitening of hair",
      "Loss of color in tissues inside mouth",
      "Change in color of inner layer of eye",
    ],
    prevention: ["No known prevention"],
    complications: ["Sunburn", "Social or psychological distress", "Eye problems", "Hearing loss"],
  },
  {
    name: "Shingles",
    description:
      "A viral infection that causes a painful rash, caused by the varicella-zoster virus, the same virus that causes chickenpox.",
    medicines: ["Acyclovir", "Valacyclovir"],
    category: "Dermatological",
    symptoms: [
      "Pain, burning, numbness or tingling",
      "Sensitivity to touch",
      "Red rash",
      "Fluid-filled blisters",
      "Itching",
    ],
    prevention: ["Shingles vaccine", "Chickenpox vaccine"],
    complications: ["Postherpetic neuralgia", "Vision loss", "Neurological problems", "Skin infections"],
  },
  {
    name: "Alopecia Areata",
    description:
      "An autoimmune disorder that causes unpredictable, patchy hair loss on the scalp, face, and sometimes other areas of the body.",
    medicines: ["Corticosteroid injections", "Minoxidil"],
    category: "Dermatological",
    symptoms: [
      "Small, round patches of hair loss",
      "Hair loss at beard, eyebrows, or eyelashes",
      "Exclamation mark hairs",
      "Nail pitting",
    ],
    prevention: ["No known prevention"],
    complications: ["Psychological distress", "Social anxiety", "Complete hair loss"],
  },

  // Musculoskeletal Conditions
  {
    name: "Osteoarthritis",
    description:
      "A degenerative joint disease that occurs when the protective cartilage that cushions the ends of your bones wears down over time.",
    medicines: ["Acetaminophen", "Celecoxib"],
    category: "Musculoskeletal",
    symptoms: ["Joint pain", "Stiffness", "Tenderness", "Loss of flexibility", "Grating sensation", "Bone spurs"],
    prevention: ["Maintaining healthy weight", "Regular exercise", "Protecting joints", "Good posture"],
    complications: ["Chronic pain", "Difficulty moving affected joints", "Sleep disturbances", "Depression"],
  },
  {
    name: "Osteoporosis",
    description:
      "A bone disease that occurs when the body loses too much bone, makes too little bone, or both, resulting in weak and brittle bones.",
    medicines: ["Alendronate", "Denosumab"],
    category: "Musculoskeletal",
    symptoms: ["Back pain", "Loss of height", "Stooped posture", "Bone fractures with minimal trauma"],
    prevention: ["Calcium and vitamin D", "Regular exercise", "Not smoking", "Limited alcohol consumption"],
    complications: ["Bone fractures", "Compressed vertebrae", "Limited mobility", "Decreased quality of life"],
  },
  {
    name: "Fibromyalgia",
    description:
      "A disorder characterized by widespread musculoskeletal pain accompanied by fatigue, sleep, memory and mood issues.",
    medicines: ["Pregabalin", "Duloxetine"],
    category: "Musculoskeletal",
    symptoms: ["Widespread pain", "Fatigue", "Cognitive difficulties", "Sleep problems", "Headaches", "Depression"],
    prevention: ["No known prevention", "Stress reduction may help"],
    complications: ["Depression", "Social isolation", "Decreased quality of life"],
  },
  {
    name: "Gout",
    description:
      "A form of inflammatory arthritis characterized by recurrent attacks of a red, tender, hot, and swollen joint, caused by elevated levels of uric acid.",
    medicines: ["Colchicine", "Allopurinol"],
    category: "Musculoskeletal",
    symptoms: ["Intense joint pain", "Lingering discomfort", "Inflammation and redness", "Limited range of motion"],
    prevention: [
      "Limiting alcohol",
      "Limiting foods high in purines",
      "Maintaining healthy weight",
      "Staying hydrated",
    ],
    complications: ["Recurrent gout", "Advanced gout", "Kidney stones", "Tophi (urate crystal deposits)"],
  },
  {
    name: "Carpal Tunnel Syndrome",
    description:
      "A condition that causes numbness, tingling, and weakness in the hand and arm due to pressure on the median nerve in the wrist.",
    medicines: ["Naproxen", "Corticosteroid injections"],
    category: "Musculoskeletal",
    symptoms: ["Numbness or tingling", "Hand weakness", "Shock-like sensations", "Pain radiating up arm"],
    prevention: [
      "Taking breaks from repetitive activities",
      "Proper posture",
      "Wrist-strengthening exercises",
      "Ergonomic workspace",
    ],
    complications: ["Permanent nerve damage", "Muscle atrophy", "Decreased hand function"],
  },
  {
    name: "Ankylosing Spondylitis",
    description:
      "An inflammatory disease that can cause some of the vertebrae in your spine to fuse, resulting in a hunched-forward posture.",
    medicines: ["Naproxen", "Adalimumab"],
    category: "Musculoskeletal",
    symptoms: ["Lower back pain", "Early morning stiffness", "Neck pain", "Fatigue", "Pain in large joints"],
    prevention: ["No known prevention"],
    complications: [
      "Difficulty breathing",
      "Eye inflammation",
      "Heart problems",
      "Compression fractures",
      "Cauda equina syndrome",
    ],
  },
  {
    name: "Bursitis",
    description:
      "Inflammation of the fluid-filled pads (bursae) that act as cushions at the joints, causing pain and limiting movement.",
    medicines: ["Ibuprofen", "Corticosteroid injections"],
    category: "Musculoskeletal",
    symptoms: ["Joint pain", "Joint tenderness", "Swelling", "Warmth", "Redness", "Limited movement"],
    prevention: [
      "Protecting joints",
      "Taking breaks from repetitive tasks",
      "Maintaining strength and flexibility",
      "Using proper technique",
    ],
    complications: ["Chronic pain", "Limited mobility", "Muscle atrophy", "Frozen shoulder"],
  },
  {
    name: "Tendinitis",
    description:
      "Inflammation or irritation of a tendon, the thick fibrous cords that attach muscle to bone, causing pain and tenderness just outside a joint.",
    medicines: ["Ibuprofen", "Corticosteroid injections"],
    category: "Musculoskeletal",
    symptoms: [
      "Pain with movement",
      "Tenderness",
      "Mild swelling",
      "Warmth",
      "Redness",
      "Crackling sound with movement",
    ],
    prevention: [
      "Limiting repetitive movements",
      "Using proper technique",
      "Improving strength and flexibility",
      "Taking breaks",
    ],
    complications: ["Tendon rupture", "Chronic pain", "Limited mobility"],
  },

  // Cancer
  {
    name: "Breast Cancer",
    description:
      "A type of cancer that forms in the cells of the breasts, typically beginning in the milk ducts or lobules.",
    medicines: ["Tamoxifen", "Trastuzumab"],
    category: "Cancer",
    symptoms: [
      "Lump in breast",
      "Change in breast size or shape",
      "Skin dimpling",
      "Nipple inversion",
      "Nipple discharge",
      "Redness or scaling",
    ],
    prevention: [
      "Regular screening",
      "Limiting alcohol",
      "Maintaining healthy weight",
      "Physical activity",
      "Breastfeeding",
    ],
    complications: ["Metastasis", "Recurrence", "Psychological impact", "Lymphedema"],
  },
  {
    name: "Lung Cancer",
    description:
      "A type of cancer that begins in the lungs, usually in the cells lining the air passages, most commonly caused by smoking.",
    medicines: ["Pembrolizumab", "Osimertinib"],
    category: "Cancer",
    symptoms: [
      "Persistent cough",
      "Coughing up blood",
      "Chest pain",
      "Shortness of breath",
      "Hoarseness",
      "Weight loss",
    ],
    prevention: ["Not smoking", "Avoiding secondhand smoke", "Testing for radon", "Avoiding carcinogens"],
    complications: ["Respiratory failure", "Metastasis", "Pleural effusion", "Paraneoplastic syndromes"],
  },
  {
    name: "Colorectal Cancer",
    description:
      "Cancer that starts in the colon or rectum, often beginning as small, noncancerous clumps of cells called polyps.",
    medicines: ["Fluorouracil", "Bevacizumab"],
    category: "Cancer",
    symptoms: [
      "Change in bowel habits",
      "Rectal bleeding",
      "Persistent abdominal discomfort",
      "Weakness or fatigue",
      "Unexplained weight loss",
    ],
    prevention: [
      "Regular screening",
      "High-fiber diet",
      "Limited red meat",
      "Regular exercise",
      "Maintaining healthy weight",
    ],
    complications: ["Bowel obstruction", "Metastasis", "Recurrence", "Peritoneal carcinomatosis"],
  },
  {
    name: "Prostate Cancer",
    description:
      "A type of cancer that occurs in the prostate, a small walnut-shaped gland in men that produces seminal fluid.",
    medicines: ["Enzalutamide", "Abiraterone"],
    category: "Cancer",
    symptoms: [
      "Difficulty urinating",
      "Decreased force of urination",
      "Blood in semen",
      "Discomfort in pelvic area",
      "Bone pain",
      "Erectile dysfunction",
    ],
    prevention: ["Healthy diet", "Regular exercise", "Maintaining healthy weight"],
    complications: ["Metastasis", "Incontinence", "Erectile dysfunction", "Psychological impact"],
  },
  {
    name: "Skin Cancer",
    description:
      "The abnormal growth of skin cells, most often developing on skin exposed to the sun, including basal cell carcinoma, squamous cell carcinoma, and melanoma.",
    medicines: ["Fluorouracil cream", "Imiquimod cream"],
    category: "Cancer",
    symptoms: [
      "Unusual skin growth",
      "Sore that doesn't heal",
      "Change in existing mole",
      "Dome-shaped growth",
      "Scaly patch",
    ],
    prevention: ["Sun protection", "Avoiding tanning beds", "Regular skin checks", "Protective clothing"],
    complications: ["Disfigurement", "Metastasis (especially with melanoma)", "Recurrence"],
  },
  {
    name: "Leukemia",
    description:
      "A cancer of blood-forming tissues, including bone marrow and the lymphatic system, affecting the production and function of blood cells.",
    medicines: ["Imatinib", "Venetoclax"],
    category: "Cancer",
    symptoms: [
      "Fatigue",
      "Frequent infections",
      "Weight loss",
      "Swollen lymph nodes",
      "Easy bleeding or bruising",
      "Recurrent nosebleeds",
    ],
    prevention: ["Avoiding smoking", "Limiting exposure to chemicals like benzene", "Radiation protection"],
    complications: ["Frequent infections", "Bleeding", "Anemia", "Organ infiltration"],
  },
  {
    name: "Pancreatic Cancer",
    description:
      "A cancer that forms in the tissues of the pancreas, a large organ behind the stomach that produces hormones and digestive juices.",
    medicines: ["Gemcitabine", "Nab-paclitaxel"],
    category: "Cancer",
    symptoms: [
      "Abdominal pain radiating to back",
      "Loss of appetite",
      "Unintended weight loss",
      "Jaundice",
      "Light-colored stools",
      "Dark urine",
    ],
    prevention: ["Not smoking", "Maintaining healthy weight", "Limiting alcohol", "Healthy diet"],
    complications: ["Jaundice", "Pain", "Bowel obstruction", "Weight loss", "Diabetes"],
  },
  {
    name: "Ovarian Cancer",
    description:
      "A type of cancer that begins in the ovaries, the female reproductive organs that produce eggs and hormones.",
    medicines: ["Paclitaxel", "Carboplatin"],
    category: "Cancer",
    symptoms: [
      "Abdominal bloating",
      "Pelvic discomfort",
      "Quick feeling of fullness",
      "Urinary urgency",
      "Fatigue",
      "Changes in bowel habits",
    ],
    prevention: ["Oral contraceptives", "Pregnancy and breastfeeding", "Tubal ligation", "Hysterectomy"],
    complications: ["Ascites", "Pleural effusion", "Bowel obstruction", "Metastasis"],
  },
]

// Helper functions to work with the disease database

export function getDiseaseByName(name: string): DiseaseEntry | undefined {
  const normalizedName = name.toLowerCase().trim()
  return diseaseDatabase.find((disease) => disease.name.toLowerCase() === normalizedName)
}

export function searchDiseases(query: string): DiseaseEntry[] {
  const normalizedQuery = query.toLowerCase().trim()
  return diseaseDatabase.filter(
    (disease) =>
      disease.name.toLowerCase().includes(normalizedQuery) ||
      disease.description.toLowerCase().includes(normalizedQuery),
  )
}

export function getDiseasesByCategory(category: string): DiseaseEntry[] {
  const normalizedCategory = category.toLowerCase().trim()
  return diseaseDatabase.filter((disease) => disease.category.toLowerCase() === normalizedCategory)
}

export function getAllDiseaseCategories(): string[] {
  const categories = new Set<string>()
  diseaseDatabase.forEach((disease) => categories.add(disease.category))
  return Array.from(categories)
}

export function getAllDiseases(): DiseaseEntry[] {
  return diseaseDatabase
}

export function getDiseasesBySymptom(symptom: string): DiseaseEntry[] {
  const normalizedSymptom = symptom.toLowerCase().trim()
  return diseaseDatabase.filter((disease) => disease.symptoms?.some((s) => s.toLowerCase().includes(normalizedSymptom)))
}

export function getDiseasesByMedicine(medicine: string): DiseaseEntry[] {
  const normalizedMedicine = medicine.toLowerCase().trim()
  return diseaseDatabase.filter((disease) =>
    disease.medicines.some((m) => m.toLowerCase().includes(normalizedMedicine)),
  )
}
