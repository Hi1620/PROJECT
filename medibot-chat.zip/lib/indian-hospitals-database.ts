export interface IndianHospital {
  id: string
  name: string
  address: string
  pincode: string
  city: string
  state: string
  phone: string
  emergencyPhone?: string
  website?: string
  specialties: string[]
  type: "Government" | "Private" | "Trust"
  rating: number
  distance?: number
  latitude?: number
  longitude?: number
  services: string[]
  timings: string
  emergencyServices: boolean
}

export const indianHospitalsDatabase: IndianHospital[] = [
  // Delhi Hospitals
  {
    id: "aiims-delhi",
    name: "All India Institute of Medical Sciences (AIIMS)",
    address: "Sri Aurobindo Marg, Ansari Nagar, New Delhi",
    pincode: "110029",
    city: "New Delhi",
    state: "Delhi",
    phone: "+91-11-26588500",
    emergencyPhone: "+91-11-26588663",
    website: "https://www.aiims.edu",
    specialties: ["Cardiology", "Neurology", "Oncology", "Emergency Medicine", "Trauma Care"],
    type: "Government",
    rating: 4.8,
    services: ["24x7 Emergency", "ICU", "Blood Bank", "Pharmacy", "Ambulance"],
    timings: "24 Hours",
    emergencyServices: true,
  },
  {
    id: "fortis-delhi",
    name: "Fortis Hospital Shalimar Bagh",
    address: "A Block, Shalimar Bagh, New Delhi",
    pincode: "110088",
    city: "New Delhi",
    state: "Delhi",
    phone: "+91-11-47135000",
    emergencyPhone: "+91-11-47135911",
    website: "https://www.fortishealthcare.com",
    specialties: ["Cardiology", "Orthopedics", "Gastroenterology", "Emergency Care"],
    type: "Private",
    rating: 4.5,
    services: ["24x7 Emergency", "ICU", "Blood Bank", "Pharmacy", "Ambulance"],
    timings: "24 Hours",
    emergencyServices: true,
  },
  {
    id: "max-delhi",
    name: "Max Super Speciality Hospital Saket",
    address: "1, 2, Press Enclave Road, Saket, New Delhi",
    pincode: "110017",
    city: "New Delhi",
    state: "Delhi",
    phone: "+91-11-26515050",
    emergencyPhone: "+91-11-26515911",
    website: "https://www.maxhealthcare.in",
    specialties: ["Cardiology", "Neurology", "Oncology", "Emergency Medicine"],
    type: "Private",
    rating: 4.6,
    services: ["24x7 Emergency", "ICU", "Blood Bank", "Pharmacy", "Ambulance"],
    timings: "24 Hours",
    emergencyServices: true,
  },

  // Mumbai Hospitals
  {
    id: "kh-mumbai",
    name: "King Edward Memorial Hospital (KEM)",
    address: "Acharya Donde Marg, Parel, Mumbai",
    pincode: "400012",
    city: "Mumbai",
    state: "Maharashtra",
    phone: "+91-22-24136051",
    emergencyPhone: "+91-22-24136911",
    website: "https://www.kemhospitalmumbai.org",
    specialties: ["Emergency Medicine", "Trauma Care", "General Medicine", "Surgery"],
    type: "Government",
    rating: 4.3,
    services: ["24x7 Emergency", "ICU", "Blood Bank", "Pharmacy", "Ambulance"],
    timings: "24 Hours",
    emergencyServices: true,
  },
  {
    id: "kokilaben-mumbai",
    name: "Kokilaben Dhirubhai Ambani Hospital",
    address: "Rao Saheb Achutrao Patwardhan Marg, Four Bunglows, Andheri West, Mumbai",
    pincode: "400053",
    city: "Mumbai",
    state: "Maharashtra",
    phone: "+91-22-42696969",
    emergencyPhone: "+91-22-42696911",
    website: "https://www.kokilabenhospital.com",
    specialties: ["Cardiology", "Neurology", "Oncology", "Emergency Care", "Transplant"],
    type: "Private",
    rating: 4.7,
    services: ["24x7 Emergency", "ICU", "Blood Bank", "Pharmacy", "Ambulance"],
    timings: "24 Hours",
    emergencyServices: true,
  },
  {
    id: "lilavati-mumbai",
    name: "Lilavati Hospital and Research Centre",
    address: "A-791, Bandra Reclamation, Bandra West, Mumbai",
    pincode: "400050",
    city: "Mumbai",
    state: "Maharashtra",
    phone: "+91-22-26567777",
    emergencyPhone: "+91-22-26567911",
    website: "https://www.lilavatihospital.com",
    specialties: ["Cardiology", "Neurology", "Emergency Medicine", "Critical Care"],
    type: "Private",
    rating: 4.5,
    services: ["24x7 Emergency", "ICU", "Blood Bank", "Pharmacy", "Ambulance"],
    timings: "24 Hours",
    emergencyServices: true,
  },

  // Bangalore Hospitals
  {
    id: "nimhans-bangalore",
    name: "National Institute of Mental Health and Neurosciences (NIMHANS)",
    address: "Hosur Road, Bangalore",
    pincode: "560029",
    city: "Bangalore",
    state: "Karnataka",
    phone: "+91-80-26995000",
    emergencyPhone: "+91-80-26995911",
    website: "https://www.nimhans.ac.in",
    specialties: ["Neurology", "Psychiatry", "Emergency Medicine", "Neurosurgery"],
    type: "Government",
    rating: 4.6,
    services: ["24x7 Emergency", "ICU", "Blood Bank", "Pharmacy", "Ambulance"],
    timings: "24 Hours",
    emergencyServices: true,
  },
  {
    id: "manipal-bangalore",
    name: "Manipal Hospital Old Airport Road",
    address: "98, Rustum Bagh, Airport Road, Bangalore",
    pincode: "560017",
    city: "Bangalore",
    state: "Karnataka",
    phone: "+91-80-25023200",
    emergencyPhone: "+91-80-25023911",
    website: "https://www.manipalhospitals.com",
    specialties: ["Cardiology", "Orthopedics", "Emergency Care", "Critical Care"],
    type: "Private",
    rating: 4.4,
    services: ["24x7 Emergency", "ICU", "Blood Bank", "Pharmacy", "Ambulance"],
    timings: "24 Hours",
    emergencyServices: true,
  },

  // Chennai Hospitals
  {
    id: "apollo-chennai",
    name: "Apollo Hospital Chennai",
    address: "21, Greams Lane, Off Greams Road, Chennai",
    pincode: "600006",
    city: "Chennai",
    state: "Tamil Nadu",
    phone: "+91-44-28290200",
    emergencyPhone: "+91-44-28290911",
    website: "https://www.apollohospitals.com",
    specialties: ["Cardiology", "Oncology", "Neurology", "Emergency Medicine"],
    type: "Private",
    rating: 4.6,
    services: ["24x7 Emergency", "ICU", "Blood Bank", "Pharmacy", "Ambulance"],
    timings: "24 Hours",
    emergencyServices: true,
  },
  {
    id: "stanley-chennai",
    name: "Government Stanley Medical College Hospital",
    address: "Old Jail Road, Royapuram, Chennai",
    pincode: "600001",
    city: "Chennai",
    state: "Tamil Nadu",
    phone: "+91-44-25281351",
    emergencyPhone: "+91-44-25281911",
    website: "https://www.stanleymedicalcollege.in",
    specialties: ["Emergency Medicine", "General Medicine", "Surgery", "Trauma Care"],
    type: "Government",
    rating: 4.2,
    services: ["24x7 Emergency", "ICU", "Blood Bank", "Pharmacy", "Ambulance"],
    timings: "24 Hours",
    emergencyServices: true,
  },

  // Hyderabad Hospitals
  {
    id: "nims-hyderabad",
    name: "Nizam's Institute of Medical Sciences (NIMS)",
    address: "Punjagutta, Hyderabad",
    pincode: "500082",
    city: "Hyderabad",
    state: "Telangana",
    phone: "+91-40-23489000",
    emergencyPhone: "+91-40-23489911",
    website: "https://www.nims.edu.in",
    specialties: ["Cardiology", "Neurology", "Emergency Medicine", "Critical Care"],
    type: "Government",
    rating: 4.4,
    services: ["24x7 Emergency", "ICU", "Blood Bank", "Pharmacy", "Ambulance"],
    timings: "24 Hours",
    emergencyServices: true,
  },
  {
    id: "apollo-hyderabad",
    name: "Apollo Hospital Jubilee Hills",
    address: "Road No. 72, Jubilee Hills, Hyderabad",
    pincode: "500033",
    city: "Hyderabad",
    state: "Telangana",
    phone: "+91-40-23607777",
    emergencyPhone: "+91-40-23607911",
    website: "https://www.apollohospitals.com",
    specialties: ["Cardiology", "Oncology", "Neurology", "Emergency Care"],
    type: "Private",
    rating: 4.5,
    services: ["24x7 Emergency", "ICU", "Blood Bank", "Pharmacy", "Ambulance"],
    timings: "24 Hours",
    emergencyServices: true,
  },

  // Kolkata Hospitals
  {
    id: "sskm-kolkata",
    name: "SSKM Hospital",
    address: "244, AJC Bose Road, Kolkata",
    pincode: "700020",
    city: "Kolkata",
    state: "West Bengal",
    phone: "+91-33-22234567",
    emergencyPhone: "+91-33-22234911",
    website: "https://www.ipgmer.gov.in",
    specialties: ["Emergency Medicine", "General Medicine", "Surgery", "Cardiology"],
    type: "Government",
    rating: 4.1,
    services: ["24x7 Emergency", "ICU", "Blood Bank", "Pharmacy", "Ambulance"],
    timings: "24 Hours",
    emergencyServices: true,
  },
  {
    id: "apollo-kolkata",
    name: "Apollo Gleneagles Hospital",
    address: "58, Canal Circular Road, Kolkata",
    pincode: "700054",
    city: "Kolkata",
    state: "West Bengal",
    phone: "+91-33-23203040",
    emergencyPhone: "+91-33-23203911",
    website: "https://www.apollohospitals.com",
    specialties: ["Cardiology", "Neurology", "Oncology", "Emergency Care"],
    type: "Private",
    rating: 4.4,
    services: ["24x7 Emergency", "ICU", "Blood Bank", "Pharmacy", "Ambulance"],
    timings: "24 Hours",
    emergencyServices: true,
  },

  // Pune Hospitals
  {
    id: "ruby-pune",
    name: "Ruby Hall Clinic",
    address: "40, Sassoon Road, Pune",
    pincode: "411001",
    city: "Pune",
    state: "Maharashtra",
    phone: "+91-20-26127100",
    emergencyPhone: "+91-20-26127911",
    website: "https://www.rubyhall.com",
    specialties: ["Cardiology", "Neurology", "Emergency Medicine", "Critical Care"],
    type: "Private",
    rating: 4.3,
    services: ["24x7 Emergency", "ICU", "Blood Bank", "Pharmacy", "Ambulance"],
    timings: "24 Hours",
    emergencyServices: true,
  },
  {
    id: "kh-pune",
    name: "KEM Hospital Pune",
    address: "Rasta Peth, Pune",
    pincode: "411011",
    city: "Pune",
    state: "Maharashtra",
    phone: "+91-20-26127300",
    emergencyPhone: "+91-20-26127911",
    website: "https://www.kemhospitalpune.org",
    specialties: ["Emergency Medicine", "General Medicine", "Surgery", "Trauma Care"],
    type: "Government",
    rating: 4.0,
    services: ["24x7 Emergency", "ICU", "Blood Bank", "Pharmacy", "Ambulance"],
    timings: "24 Hours",
    emergencyServices: true,
  },
]

// Helper functions
export function getHospitalsByPincode(pincode: string): IndianHospital[] {
  return indianHospitalsDatabase.filter((hospital) => hospital.pincode === pincode)
}

export function getHospitalsByCity(city: string): IndianHospital[] {
  return indianHospitalsDatabase.filter((hospital) => hospital.city.toLowerCase().includes(city.toLowerCase()))
}

export function getNearbyHospitals(pincode: string, radius = 10): IndianHospital[] {
  // For demo purposes, we'll return hospitals from the same city and nearby pincodes
  const exactMatch = getHospitalsByPincode(pincode)
  if (exactMatch.length > 0) {
    return exactMatch
  }

  // Find hospitals in nearby pincodes (simplified logic)
  const pincodeNum = Number.parseInt(pincode)
  const nearbyHospitals = indianHospitalsDatabase.filter((hospital) => {
    const hospitalPincode = Number.parseInt(hospital.pincode)
    return Math.abs(hospitalPincode - pincodeNum) <= 50 // Within 50 pincode range
  })

  return nearbyHospitals.slice(0, 10) // Return max 10 results
}

export function searchHospitals(query: string): IndianHospital[] {
  const searchTerm = query.toLowerCase()
  return indianHospitalsDatabase.filter(
    (hospital) =>
      hospital.name.toLowerCase().includes(searchTerm) ||
      hospital.city.toLowerCase().includes(searchTerm) ||
      hospital.specialties.some((specialty) => specialty.toLowerCase().includes(searchTerm)),
  )
}

export function getEmergencyNumbers() {
  return {
    national: "112", // National Emergency Number
    police: "100",
    fire: "101",
    ambulance: "108",
    women: "1091",
    child: "1098",
    disaster: "1070",
    tourist: "1363",
  }
}
